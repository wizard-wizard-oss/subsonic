# Pi Media Station

Station musicale sur Raspberry Pi (écran tactile 7", ampli USB) : menu tactile, interface web pour un serveur
Subsonic, podcasts, radios, AirPlay/Bluetooth, lecture haute fidélité par mpv, file d'attente partagée avec les
téléphones. Le même serveur sert aussi en mode multi-utilisateurs derrière Apache.

## Organisation

| Dossier | Rôle |
|---|---|
| `pimedia/server/` | serveur HTTP : `transport` (requêtes, routes), `controllers/` (minces), services métier (`podcasts/`, `extmusic/`, `queue.py`, `playback.py`…), clients externes (`upstream.py` pour Subsonic…). Assemblage unique dans `app.py`. |
| `pimedia/storage/` | base SQLite : `database.py` (connexions, transactions), `schema.py` (migrations numérotées), un dépôt par domaine, `legacy.py` (import unique des anciens JSON). |
| `pimedia/entities.py` | entités métier (dataclasses) renvoyées par les dépôts ; `to_api()` donne le JSON de la page. |
| `pimedia/settings.py`, `envfile.py` | réglages : base (modifiés dans l'appli) > `PI_MEDIA_*` > `.env` > défaut. |
| `i18n/fr.yaml` | tous les textes, clés en anglais. |
| `web/` | page web (JS sans outil de build). |
| `launcher.py` | menu tactile Tk (à découper : étape 2 de la refonte). |
| `deploy/` | archive, `deploy.sh`, service systemd, scripts de réglage. |
| `tests/` | unitaires et intégration (faux Subsonic, faux mpv), parcours navigateur (jsdom). |

Tables et colonnes en anglais ; données dans `~/.local/share/pi-media/` (`.env`, `pi-media.db`), jamais dans le code.

## Commandes

```bash
python3 -m unittest discover -s tests -t .          # tests
python3 deploy/build_archive.py                      # dist/pi-media-<version>.tar.gz + dist/deploy.sh
bash deploy.sh pi-media-<version>.tar.gz             # sur le Pi : installe, démarre, vérifie (retour arrière si échec)
bash deploy.sh --rollback | --status
python3 -m pimedia.cli set SUBSONIC_URL=… SUBSONIC_USER=… SUBSONIC_PASS=…
```

Réglages : copier `.env.example` en `~/.local/share/pi-media/.env`.
