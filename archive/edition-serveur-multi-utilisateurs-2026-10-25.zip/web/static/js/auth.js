"use strict";
// Connexion (mode serveur)

function showLogin() { $("#login").hidden = false; setTimeout(() => $("#lg_user").focus(), 50); }
$("#loginform").onsubmit = async e => {
  e.preventDefault();
  $("#lg_err").textContent = "";
  try {
    const r = await fetch("/login", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({user: $("#lg_user").value, pass: $("#lg_pass").value})});
    const j = await r.json().catch(() => ({}));
    if (r.ok) { location.reload(); return; }
    $("#lg_err").textContent = j.error || "Connexion impossible";
  } catch (err) { $("#lg_err").textContent = "Serveur injoignable"; }
};
