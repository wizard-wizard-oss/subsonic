"use strict";
// Envoi de musique (ZIP)

/* ---------- Envoi de musique (ZIP) ---------- */
function uploadView(c) {
  const wrap = document.createElement("div"); wrap.className = "upl";
  wrap.innerHTML =
    "<p>Envoyez un fichier <b>ZIP</b> de musique (MP3, FLAC, OGG, M4A…, pochettes comprises). " +
    "L’idéal est une arborescence <b>Artiste / Album / titres</b>. Taille maximale : " + (ME.upload_max_mb || 0) + " Mo. " +
    "Les titres déjà présents sont ignorés.</p>" +
    '<input type="text" id="up_artist" placeholder="Artiste (seulement si votre ZIP contient Album / titres, sans dossier artiste)">' +
    '<div class="drop" id="up_drop">Glissez votre ZIP ici<br>ou touchez pour choisir un fichier</div>' +
    '<input type="file" id="up_file" accept=".zip,application/zip" hidden>' +
    '<div class="bar" id="up_bar" hidden><i></i></div><div class="st" id="up_st"></div>' +
    '<div id="up_jobs"></div>';
  c.appendChild(wrap);
  const drop = wrap.querySelector("#up_drop"), file = wrap.querySelector("#up_file");
  const bar = wrap.querySelector("#up_bar"), st = wrap.querySelector("#up_st"), jobs = wrap.querySelector("#up_jobs");
  let busy = false, timer = null;
  const say = (t, err) => { st.textContent = t; st.className = "st" + (err ? " err" : ""); };
  const label = j => {
    if (j.state === "erreur") return '<b class="err">Échec</b> — ' + esc(j.error || "");
    if (j.state === "termine") {
      let t = "<b>Terminé</b> — " + j.added + " fichier(s) ajouté(s)";
      if (j.existants) t += ", " + j.existants + " déjà présent(s)";
      if (j.ignores) t += ", " + j.ignores + " ignoré(s) (non audio)";
      if (j.dangereux) t += ", " + j.dangereux + " refusé(s)";
      t += ".";
      if (j.a_classer) t += " Rangés dans « À classer » : ils seront triés ensuite.";
      return t + " Visibles dans la bibliothèque après le prochain scan (quelques minutes).";
    }
    if (j.state === "extraction") return "Extraction " + j.done + " / " + j.total + "…";
    return {reception: "Réception…", attente: "En attente…", analyse: "Analyse de l’archive…"}[j.state] || j.state;
  };
  async function refresh() {
    try {
      const list = await (await fetch("/upload/list")).json();
      jobs.innerHTML = "";
      list.forEach(j => { const d = document.createElement("div"); d.className = "job"; d.innerHTML = "<b>" + esc(j.name) + "</b><br>" + label(j); jobs.appendChild(d); });
      const active = list.some(j => ["reception", "attente", "analyse", "extraction"].includes(j.state));
      clearTimeout(timer);
      if (active && $("#up_jobs") === jobs) timer = setTimeout(refresh, 1500);
      else busy = false;
    } catch (e) { busy = false; }
  }
  function send(f) {
    if (busy) return;
    if (!/\.zip$/i.test(f.name)) { say("Choisissez un fichier .zip", true); return; }
    if (ME.upload_max_mb && f.size > ME.upload_max_mb * 1048576) { say("Fichier trop gros (maximum " + ME.upload_max_mb + " Mo)", true); return; }
    busy = true; say("Envoi de " + f.name + "…"); bar.hidden = false; bar.firstChild.style.width = "0";
    const x = new XMLHttpRequest();
    x.open("POST", "/upload?name=" + encodeURIComponent(f.name) + "&artist=" + encodeURIComponent(wrap.querySelector("#up_artist").value.trim()));
    x.setRequestHeader("X-Requested-With", "pm");
    x.upload.onprogress = e => {
      if (e.lengthComputable) { bar.firstChild.style.width = (100 * e.loaded / e.total) + "%"; say("Envoi : " + Math.round(100 * e.loaded / e.total) + " %"); }
    };
    x.onload = () => {
      bar.hidden = true;
      if (x.status === 401) { showLogin(); busy = false; return; }
      let j = {}; try { j = JSON.parse(x.responseText); } catch (e) {}
      if (x.status === 202) { say("Envoi terminé, traitement en cours…"); refresh(); }
      else { say(j.error || "Échec de l’envoi (" + x.status + ")", true); busy = false; }
    };
    x.onerror = () => { bar.hidden = true; say("Connexion interrompue pendant l’envoi", true); busy = false; };
    x.send(f);
  }
  drop.onclick = () => { if (!busy) file.click(); };
  file.onchange = () => { if (file.files[0]) send(file.files[0]); file.value = ""; };
  ["dragover", "dragenter"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", e => { const f = e.dataTransfer.files[0]; if (f) send(f); });
  refresh();
}
