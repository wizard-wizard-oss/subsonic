"""Format commun d'un titre (Subsonic, Jamendo, YouTube…), tel que la page l'utilise et tel qu'on le stocke."""
import urllib.parse

TRACK_KEYS = ("id", "title", "artist", "album", "albumId", "artistId", "coverArt", "duration", "track", "suffix",
              "bitRate", "bitDepth", "samplingRate", "streamUrl", "youtubeId", "imageUrl", "ext")


def clean_track(raw):
    """Ne garde que les champs connus ; refuse un titre sans identifiant ou avec une adresse de lecture étrangère."""
    if not isinstance(raw, dict) or not raw.get("id") or not raw.get("title"):
        raise ValueError("titre invalide")
    track = {k: raw[k] for k in TRACK_KEYS if k in raw and isinstance(raw[k], (str, int, float))}
    for key in ("streamUrl", "imageUrl"):
        if track.get(key) and urllib.parse.urlsplit(str(track[key])).scheme not in ("http", "https"):
            raise ValueError("adresse invalide")
    track["id"], track["title"] = str(track["id"]), str(track["title"])[:300]
    return track
