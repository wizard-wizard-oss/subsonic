"""Mode serveur : envoi de musique par fichier ZIP (contrôles de sécurité, rangement, scan Subsonic)."""
import json
import os
import re
import secrets
import shutil
import threading
import time
import zipfile

from .folders import normalize_name

AUDIO_EXT = frozenset((".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wav", ".wma", ".ape", ".wv",
                       ".aif", ".aiff", ".mka", ".mpc"))
EXTRA_EXT = frozenset((".jpg", ".jpeg", ".png", ".webp", ".lrc", ".cue"))    # pochettes, paroles, feuilles de piste
JUNK_NAMES = frozenset(("thumbs.db", "desktop.ini", ".ds_store"))
UNSORTED_FOLDER = "À classer"


class UploadRefused(Exception):
    """Envoi refusé : message pour l'utilisateur et code HTTP."""

    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ---------- noms de fichiers et reconnaissance du contenu (fonctions pures) ----------
def clean_part(part):
    """Nom de dossier ou de fichier sans caractères interdits ni points/espaces finaux."""
    part = re.sub(r'[\x00-\x1f<>:"|?*\\]', "_", part).strip()
    part = re.sub(r"\s+", " ", part).rstrip(". ")
    return part.encode("utf-8")[:200].decode("utf-8", "ignore").rstrip(". ")


def _mp3(h):
    return h[:3] == b"ID3" or (len(h) > 1 and h[0] == 0xFF and h[1] & 0xE0 == 0xE0)


def _aac(h):
    return h[:3] == b"ID3" or (len(h) > 1 and h[0] == 0xFF and h[1] & 0xF0 == 0xF0) or h[4:8] == b"ftyp"


def _starts(*prefixes):
    return lambda h: any(h[:len(p)] == p for p in prefixes)


MAGIC_CHECKS = {
    ".mp3": _mp3, ".aac": _aac,
    ".flac": _starts(b"fLaC", b"ID3"),
    ".ogg": _starts(b"OggS"), ".oga": _starts(b"OggS"), ".opus": _starts(b"OggS"),
    ".wav": lambda h: h[:4] == b"RIFF" and h[8:12] == b"WAVE",
    ".m4a": lambda h: h[4:8] == b"ftyp",
    ".wma": _starts(b"\x30\x26\xb2\x75"),
    ".ape": _starts(b"MAC "), ".wv": _starts(b"wvpk"),
    ".aif": _starts(b"FORM"), ".aiff": _starts(b"FORM"),
    ".mka": _starts(b"\x1a\x45\xdf\xa3"),
    ".mpc": _starts(b"MP+", b"MPCK"),
    ".jpg": _starts(b"\xff\xd8\xff"), ".jpeg": _starts(b"\xff\xd8\xff"),
    ".png": _starts(b"\x89PNG"),
    ".webp": lambda h: h[:4] == b"RIFF" and h[8:12] == b"WEBP",
    ".lrc": lambda h: b"\x00" not in h, ".cue": lambda h: b"\x00" not in h,
}


def magic_ok(ext, head):
    """Le début du fichier correspond-il à son extension ? (un « .mp3 » qui contient autre chose est refusé)"""
    check = MAGIC_CHECKS.get(ext)
    return bool(check and check(head))


# ---------- analyse de l'archive ----------
class ZipPlan:
    def __init__(self, items, ignored, dangerous, unsorted):
        self.items = items              # [(ZipInfo, [dossiers], nom)]
        self.ignored = ignored
        self.dangerous = dangerous
        self.unsorted = unsorted


class ZipPlanner:
    """Décide quoi extraire : seulement l'audio et ses fichiers associés, jamais de chemin dangereux,
    avec le classement Artiste/Album/titre (ou « À classer » quand l'archive n'en dit rien)."""

    MAX_FILES = 20000
    MAX_DEPTH = 7
    MAX_FILE_BYTES = 2 * 1073741824

    def __init__(self, max_unzipped):
        self.max_unzipped = max_unzipped

    def plan(self, infos, artist, zip_name):
        if len(infos) > self.MAX_FILES:
            raise ValueError("Archive trop volumineuse (plus de 20 000 fichiers)")
        stats = {"ignored": 0, "dangerous": 0}
        items = [item for item in (self._classify(info, stats) for info in infos) if item]
        if sum(i[0].file_size for i in items) > self.max_unzipped:
            raise ValueError("Contenu décompressé trop gros")
        prefix, unsorted = self._prefix(items, artist, zip_name)
        return ZipPlan([(i, prefix + d, n) for i, d, n in items], stats["ignored"], stats["dangerous"], unsorted)

    # --- une entrée de l'archive ---
    def _classify(self, info, stats):
        name = info.filename.replace("\\", "/")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if name.endswith("/") or not parts:
            return None
        if self._is_dangerous(info, name, parts):
            stats["dangerous"] += 1
            return None
        cleaned = self._wanted(info, parts)
        if cleaned is None:
            stats["ignored"] += 1
            return None
        return info, cleaned[:-1], cleaned[-1]

    @staticmethod
    def _is_dangerous(info, name, parts):
        return (".." in parts or name.startswith("/") or bool(re.match(r"^[A-Za-z]:", name))
                or bool(info.flag_bits & 0x1)                                   # entrée chiffrée
                or (info.external_attr >> 16) & 0o170000 == 0o120000)           # lien symbolique

    def _wanted(self, info, parts):
        """Chemin nettoyé si le fichier est à garder, sinon None."""
        fname = parts[-1]
        ext = os.path.splitext(fname)[1].lower()
        if ("__MACOSX" in parts or fname.startswith(".") or fname.lower() in JUNK_NAMES
                or ext not in AUDIO_EXT | EXTRA_EXT or len(parts) > self.MAX_DEPTH
                or info.file_size > self.MAX_FILE_BYTES):
            return None
        cleaned = [clean_part(p) for p in parts]
        return None if any(not p or p.startswith(".") for p in cleaned) else cleaned

    # --- classement ---
    @staticmethod
    def _prefix(items, artist, zip_name):
        depths = [len(d) for i, d, n in items if os.path.splitext(n)[1].lower() in AUDIO_EXT]
        if not depths:
            raise ValueError("Aucun fichier audio dans l'archive")
        shallowest = min(depths)
        if shallowest >= 2:
            return [], False                         # déjà du type Artiste/Album/titre
        album = clean_part(os.path.splitext(os.path.basename(zip_name))[0]) or "Envoi"
        owner = clean_part(artist or "") or UNSORTED_FOLDER
        prefix = [owner] if shallowest == 1 else [owner, album]
        return prefix, owner == UNSORTED_FOLDER


# ---------- destination ----------
class FolderMatcher:
    """Réutilise un dossier existant qui ne diffère que par la casse ou les accents (Abba / ABBA)
    pour les deux premiers niveaux (artiste et album)."""

    LEVELS = 2

    def __init__(self, root):
        self.root = root
        self._listing = {}

    def resolve(self, dirs):
        result, current = [], self.root
        for level, name in enumerate(dirs):
            if level < self.LEVELS:
                name = self._existing_twin(current, name)
            result.append(name)
            current = os.path.join(current, name)
        return result

    def _existing_twin(self, parent, name):
        for existing in self._subfolders(parent):
            if existing != name and normalize_name(existing) == normalize_name(name):
                return existing
        return name

    def _subfolders(self, parent):
        if parent not in self._listing:
            try:
                self._listing[parent] = [e for e in os.listdir(parent) if os.path.isdir(os.path.join(parent, e))]
            except OSError:
                self._listing[parent] = []
        return self._listing[parent]


class UploadJob:
    """État d'un envoi, tel que l'interface l'affiche."""

    def __init__(self, user, name, artist, size):
        self.id = secrets.token_urlsafe(8)
        self.user = user
        self.name = name
        self.artist = artist
        self.size = size
        self.state = "reception"
        self.done = 0
        self.total = 0
        self.created = time.time()
        self.fields = {}            # added, existants, ignores, dangereux, a_classer, error, fin

    def to_dict(self):
        data = {"id": self.id, "user": self.user, "name": self.name, "artist": self.artist, "state": self.state,
                "size": self.size, "done": self.done, "total": self.total, "t": self.created}
        data.update(self.fields)
        return data


class ZipExtractor:
    """Écrit les fichiers d'une archive dans le dossier de musique, en vérifiant chaque fichier."""

    CHUNK = 1048576
    MAX_TEXT_BYTES = 2097152

    def __init__(self, root, max_unzipped):
        self.root = os.path.realpath(root)
        self.max_unzipped = max_unzipped
        self.matcher = FolderMatcher(self.root)
        self._written = 0               # octets réellement écrits (toutes archives confondues)

    def extract(self, archive, plan, job):
        counts = {"added": 0, "existants": 0, "dangereux": plan.dangerous}
        job.total = len(plan.items)
        job.state = "extraction"
        self._written = 0
        for info, dirs, fname in plan.items:
            outcome = self._extract_one(archive, info, dirs, fname)
            counts[outcome] += 1
            job.done += 1
        job.fields.update(added=counts["added"], existants=counts["existants"], ignores=plan.ignored,
                          dangereux=counts["dangereux"], a_classer=plan.unsorted)

    def _extract_one(self, archive, info, dirs, fname):
        """Retourne « added », « existants » ou « dangereux »."""
        dest_dir = os.path.join(self.root, *self.matcher.resolve(dirs))
        dest = os.path.join(dest_dir, fname)
        if not os.path.realpath(dest).startswith(self.root + os.sep):
            return "dangereux"
        if os.path.exists(dest):
            return "existants"
        os.makedirs(dest_dir, exist_ok=True)
        part = dest + ".part"
        if not self._copy_checked(archive, info, fname, part):
            return "dangereux"
        os.replace(part, dest)
        self._make_readable(dest)
        return "added"

    def _copy_checked(self, archive, info, fname, part):
        """Copie en vérifiant le type réel du contenu et la taille réellement décompressée.
        Retourne False (et supprime le fichier) si le contenu est refusé."""
        ext = os.path.splitext(fname)[1].lower()
        copied = 0
        try:
            with archive.open(info) as src, open(part, "wb") as out:
                while True:
                    chunk = src.read(self.CHUNK)
                    if not chunk:
                        return True
                    if copied == 0 and not self._first_chunk_ok(ext, chunk, info):
                        out.close()
                        self._remove(part)
                        return False
                    copied += len(chunk)
                    self._written += len(chunk)
                    if copied > info.file_size + 1024 or self._written > self.max_unzipped:
                        raise ValueError("Taille décompressée incohérente")       # archive piégée
                    out.write(chunk)
        except Exception:
            self._remove(part)
            raise

    def _first_chunk_ok(self, ext, chunk, info):
        if ext in (".lrc", ".cue") and info.file_size > self.MAX_TEXT_BYTES:
            return False
        return magic_ok(ext, chunk[:4096])

    @staticmethod
    def _remove(path):
        try:
            os.remove(path)
        except OSError:
            pass

    @staticmethod
    def _make_readable(path):
        try:
            os.chmod(path, 0o644)
        except OSError:
            pass


# ---------- règles, suivi ----------
class UploadPolicy:
    """Qui peut envoyer, et dans quelles limites."""

    def __init__(self, config, accounts):
        self.config = config
        self.accounts = accounts

    def can_upload(self, user):
        if not self.config.upload_dir or not user:
            return False
        allowed = self.config.uploaders
        return self.accounts.is_admin(user) or "*" in allowed or user.lower() in allowed

    def check_destination(self):
        folder = self.config.upload_dir
        if not os.path.isdir(folder) or not os.access(folder, os.W_OK):
            raise UploadRefused(500, "Dossier d’envoi indisponible côté serveur")

    def check_size(self, length):
        if length <= 0:
            raise UploadRefused(411, "Taille du fichier inconnue")
        if length > self.config.upload_max_bytes:
            raise UploadRefused(413, "Fichier trop gros (maximum %d Mo)" % (self.config.upload_max_bytes // 1048576))

    def check_disk_space(self, length, tmp_dir):
        try:
            os.makedirs(tmp_dir, exist_ok=True)
            free = shutil.disk_usage(self.config.upload_dir).free
            free_tmp = shutil.disk_usage(tmp_dir).free
        except OSError:
            free = free_tmp = 0
        if free < length * 3 or free_tmp < length * 1.2:
            raise UploadRefused(507, "Espace disque insuffisant sur le serveur")


class UploadRegistry:
    """Envois en cours et récents ; un seul envoi à la fois par utilisateur."""

    KEEP_JOBS = 100

    def __init__(self):
        self._jobs = {}
        self._active = {}
        self._lock = threading.Lock()

    def reserve(self, user):
        with self._lock:
            if self._active.get(user, 0) >= 1:
                raise UploadRefused(429, "Un envoi est déjà en cours pour votre compte")
            self._active[user] = self._active.get(user, 0) + 1

    def release(self, user):
        with self._lock:
            self._active[user] = max(0, self._active.get(user, 1) - 1)

    def add(self, job):
        with self._lock:
            self._jobs[job.id] = job
            for old in sorted(self._jobs, key=lambda k: self._jobs[k].created)[:-self.KEEP_JOBS]:
                self._jobs.pop(old, None)

    def recent_for(self, user, limit=10):
        with self._lock:
            mine = sorted((j for j in self._jobs.values() if j.user == user), key=lambda j: -j.created)
        return [j.to_dict() for j in mine[:limit]]


class UploadLog:
    def __init__(self, path):
        self.path = path

    def write(self, job):
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(job.to_dict(), ensure_ascii=False) + "\n")
        except OSError:
            pass


class ArchiveReceiver:
    """Reçoit le corps de la requête dans un fichier temporaire."""

    CHUNK = 1048576

    def receive(self, stream, length, dest):
        try:
            self._copy(stream, length, dest)
        except Exception:
            self._discard(dest)
            raise

    def _copy(self, stream, length, dest):
        left, first = length, True
        with open(dest, "wb") as out:
            while left > 0:
                chunk = stream.read(min(self.CHUNK, left))
                if not chunk:
                    raise OSError("connexion interrompue")
                if first:
                    first = False
                    if chunk[:2] != b"PK":
                        raise ValueError("Ce n’est pas un fichier ZIP")
                out.write(chunk)
                left -= len(chunk)

    @staticmethod
    def _discard(path):
        try:
            os.remove(path)
        except OSError:
            pass


class PostUploadScan:
    """Après un envoi : demande un scan à Subsonic, puis rafraîchit nos listes un peu plus tard."""

    DELAYS = (90, 600)

    def __init__(self, client, library, watcher, holder):
        self.client = client
        self.library = library
        self.watcher = watcher
        self.holder = holder

    def run(self):
        self.client.trigger_scan()
        for delay in self.DELAYS:
            self.holder.spawn(self._refresh, delay=delay)

    def _refresh(self):
        self.library.refresh(everyone=True)
        try:
            self.watcher.check_new(True)
        except Exception:
            pass


# ---------- service ----------
class UploadService:
    def __init__(self, config, paths, policy, registry, receiver, scan, holder):
        self.config = config
        self.paths = paths
        self.policy = policy
        self.registry = registry
        self.receiver = receiver
        self.scan = scan
        self.holder = holder
        self.log = UploadLog(paths.upload_log)
        self._work = threading.Semaphore(1)         # un seul dépaquetage à la fois : on ménage le disque

    def accept(self, user, stream, length, name, artist):
        """Contrôle la demande, reçoit l'archive, lance le traitement en fond. Retourne l'identifiant de l'envoi."""
        if not self.policy.can_upload(user):
            raise UploadRefused(403, "Vous n’avez pas le droit d’envoyer de la musique")
        self.policy.check_destination()
        self.policy.check_size(length)
        self.policy.check_disk_space(length, self.paths.tmp_dir)
        self.registry.reserve(user)
        job = UploadJob(user, os.path.basename(name or "") or "envoi.zip", (artist or "")[:120], length)
        tmp = os.path.join(self.paths.tmp_dir, job.id + ".zip")
        try:
            self.receiver.receive(stream, length, tmp)
        except Exception as error:
            self.registry.release(user)
            message = str(error) if isinstance(error, ValueError) else "Envoi interrompu"
            raise UploadRefused(400, message)
        job.state = "attente"
        self.registry.add(job)
        self.holder.spawn(self._process, job, tmp)
        return job.id

    def jobs_of(self, user):
        return self.registry.recent_for(user)

    # --- traitement en fond ---
    def _process(self, job, archive_path):
        try:
            self._extract(job, archive_path)
            job.state = "termine"
            self.holder.spawn(self.scan.run)
        except Exception as error:
            job.state = "erreur"
            job.fields["error"] = str(error) if isinstance(error, ValueError) else "Archive illisible ou erreur d'écriture"
        finally:
            self._finish(job, archive_path)

    def _extract(self, job, archive_path):
        job.state = "attente"
        with self._work:
            job.state = "analyse"
            with zipfile.ZipFile(archive_path) as archive:
                limit = self.config.upload_max_unzipped_bytes
                plan = ZipPlanner(limit).plan(archive.infolist(), job.artist, job.name)
                ZipExtractor(self.config.upload_dir, limit).extract(archive, plan, job)

    def _finish(self, job, archive_path):
        try:
            os.remove(archive_path)
        except OSError:
            pass
        job.fields["fin"] = time.time()
        self.registry.release(job.user)
        self.log.write(job)
