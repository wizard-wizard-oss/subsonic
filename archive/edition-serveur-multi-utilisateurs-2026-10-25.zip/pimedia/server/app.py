"""Assemblage : crée les objets, les relie, déclare les routes et lance le serveur."""
import os

from .api import CachedApi, CoverService
from .auth import USER_CHOICES, USER_DEFAULTS, Accounts, LoginThrottle, SessionStore
from .cache import CoverCache, JsonCache
from .constants import FOREVER
from .context import ContextHolder
from .controllers.extmusic import ExtMusicController
from .controllers.history import HistoryController
from .guests import GuestWatcher
from .playback import HifiPlayer
from .controllers.player import PlayerController
from .remote import DEFAULT_PORT as PHONE_PORT, PhoneQueue, PhoneServer, RemoteController, RemoteTyping
from .queue import QueueService
from .controllers.queue import QueueController
from ..entities import Track
from ..storage.queue import PlayQueue
from .controllers.library import CacheController, InfoController, RestController
from .controllers.pages import PagesController
from .controllers.pi import GuestController, PiController, PiState, SystemVolume
from .controllers.podcasts import PodcastController
from .controllers.session import SessionController, SettingsService
from .controllers.uploads import UploadController
from .external import ExternalInfo, FactsBuilder, JsonFetcher, LyricsFinder, MusicBrainz, Wikipedia
from .extmusic.service import ExtMusicService
from .extmusic.sources import JamendoSource, YouTubeSource
from .folders import FolderAdapter
from .gate import AccessGate, SecurityHeaders
from .keys import BrowseMode, CacheKeys
from .podcasts.directories import DirectoryHub, ItunesDirectory, JsonHttp, PodcastIndexDirectory
from .podcasts.feeds import FeedFetcher, FeedReader
from .podcasts.service import PodcastService
from .policy import CachePolicy
from .transport import HttpApp, Reply, Router, ThreadedServer, make_request_handler
from .uploads import (ArchiveReceiver, PostUploadScan, UploadPolicy, UploadRegistry, UploadService)
from .upstream import SubsonicClient
from .watcher import LibraryCache, LibraryWatcher, NewestAlbums, WarmUpThrottle
from .webfiles import WebFiles
from ..envfile import EnvFile
from ..i18n import Texts
from ..paths import Paths, default_cache_dir, resolve_data_dir
from ..settings import AppSettingsStore, Settings
from ..storage.database import Database
from ..storage.history import SearchHistory
from ..storage.legacy import LegacyImport
from ..storage.playlists import LocalPlaylists
from ..storage.podcasts import PodcastLibrary
from ..storage.users import UserSettings
from ..storage.videos import UnplayableVideos


def read_version(code_dir):
    """Version déployée (fichier VERSION de l'archive) ; « dev » quand on lance depuis les sources."""
    try:
        with open(os.path.join(code_dir, "VERSION"), encoding="utf-8") as f:
            return f.read().strip() or "dev"
    except OSError:
        return "dev"


class Application:
    """Le programme complet. Toutes les dépendances sont créées ici, une seule fois, et passées aux classes
    qui en ont besoin (aucune variable globale)."""

    def __init__(self, code_dir, environ=None, data_dir=None):
        self.environ = os.environ if environ is None else environ
        data_dir = data_dir or resolve_data_dir(code_dir, self.environ)
        self.paths = Paths(code_dir, data_dir, default_cache_dir(self.environ))
        os.makedirs(data_dir, exist_ok=True)
        self.db = Database(self.paths.db_file)
        env_file = EnvFile(self.paths.env_file)
        store = AppSettingsStore(self.db)
        LegacyImport(self.paths, self.db, env_file, store).run()      # anciens config.json et JSON : une seule fois
        self.config = Settings(store, env_file, self.environ)
        self.texts = Texts(self.paths.i18n_dir, self.config.get("language"))
        self.version = read_version(code_dir)
        self.port = int(self.environ.get("PI_MEDIA_PORT", "8099"))
        self.bound_port = self.port
        self.holder = ContextHolder()
        self._build_data_layer()
        self._build_accounts()
        self._build_uploads()
        self.http = HttpApp(self._build_router(), self.gate, self.security, self.holder, self._on_error)

    # ---------- construction ----------
    def _build_data_layer(self):
        self.client = SubsonicClient(self.config, self.holder)
        self.cache = JsonCache(self.paths.json_dir)
        self.covers_cache = CoverCache(self.paths.cover_dir, FOREVER)
        self.browse = BrowseMode(self.config, self.holder)
        self.keys = CacheKeys(self.config, self.holder, self.browse)
        self.api = CachedApi(self.client, self.cache, CachePolicy(), self.keys, self.browse, self.holder)
        self.api.folders = FolderAdapter(self.api)
        self.covers = CoverService(self.client, self.covers_cache, self.keys)
        self.library = LibraryCache(self.cache, self.keys)
        self.watcher = LibraryWatcher(self.api, self.library, NewestAlbums(self.paths.newest_file))
        self.external = self._build_external()

    def _build_external(self):
        fetcher = JsonFetcher()
        musicbrainz = MusicBrainz(fetcher)
        lyrics = LyricsFinder(fetcher, self._subsonic_lyrics)
        facts = FactsBuilder(musicbrainz, Wikipedia(fetcher), self._artist_biography)
        return ExternalInfo(self.cache, self.keys, lyrics, facts, musicbrainz)

    def _subsonic_lyrics(self, artist, title):
        response = self.api.call_json("getLyrics", [("artist", artist), ("title", title)])
        return response.get("lyrics", {}).get("value", "")

    def _artist_biography(self, artist_id):
        response = self.api.call_json("getArtistInfo2", [("id", artist_id)])
        return response.get("artistInfo2", {}).get("biography", "")

    def _build_accounts(self):
        self.sessions = SessionStore(self.paths.sessions_file, self.config.session_days)
        self.user_settings = UserSettings(self.db, USER_DEFAULTS, USER_CHOICES)
        self.accounts = Accounts(self.config, self.client, self.sessions, LoginThrottle(), self.user_settings)
        self.warm_up = WarmUpThrottle(self.watcher, self.holder)
        self.security = SecurityHeaders(self.config)
        self.gate = AccessGate(self.config, self.accounts, self.holder, self.warm_up)

    def _build_uploads(self):
        self.upload_policy = UploadPolicy(self.config, self.accounts)
        scan = PostUploadScan(self.client, self.library, self.watcher, self.holder)
        self.upload_service = UploadService(self.config, self.paths, self.upload_policy, UploadRegistry(),
                                            ArchiveReceiver(), scan, self.holder)

    # ---------- routes ----------
    def _build_router(self):
        router = Router()
        self._add_common_routes(router)
        if self.config.server_mode:
            self._add_server_routes(router)
        else:
            self._add_pi_routes(router)
        return router

    def _add_common_routes(self, router):
        pages = self.pages = PagesController(WebFiles(self.paths, self.security.for_index))
        settings = SettingsService(self.config, self.browse, self.user_settings, self.holder)
        self.session_controller = SessionController(self.config, self.accounts, self.sessions, self.upload_policy,
                                                    settings, self.holder, self.warm_up)
        info = InfoController(self.external)
        cache = CacheController(self.config, self.cache, self.covers_cache, self.keys, self.library,
                                self.watcher, self.accounts, self.holder)
        rest = RestController(self.config, self.api, self.covers, self.client)
        for path in ("/", "/index.html"):
            router.add("GET", path, pages.index)
        router.add_prefix("GET", "/static/", pages.static)
        router.add("GET", "/i18n.json", lambda request: Reply.json(self.texts.section("web.")))   # textes de la page
        router.add("GET", "/health", lambda request: Reply.json({"ok": True, "version": self.version}))
        router.add("GET", "/me", self.session_controller.me)
        router.add("GET", "/settings", self.session_controller.settings_page)
        router.add("GET", "/info/genres", info.genres)
        router.add("GET", "/info/lyrics", info.lyrics)
        router.add("GET", "/info/facts", info.facts)
        router.add("GET", "/cache/refresh", cache.refresh_album)
        router.add("GET", "/cache/clear", cache.clear)
        router.add_prefix("GET", "/rest/", rest.handle)

    def _add_server_routes(self, router):
        uploads = UploadController(self.upload_service, self.holder)
        router.add("POST", "/login", self.session_controller.login)
        router.add("POST", "/logout", self.session_controller.logout)
        router.add("POST", "/upload", uploads.receive)
        router.add("GET", "/upload/list", uploads.listing)

    def _add_pi_routes(self, router):
        pi = PiController(PiState(), SystemVolume(), self.browse)
        router.add("GET", "/control/send", pi.send)
        router.add("GET", "/control/poll", pi.poll)
        router.add("GET", "/control/awake", pi.awake)
        router.add("GET", "/control/volume", pi.set_volume)
        router.add("GET", "/control/quit", pi.quit)
        router.add("GET", "/control/mode", pi.mode)
        self.guests = GuestWatcher()
        guests = GuestController(self.guests)
        socket_dir = self.environ.get("XDG_RUNTIME_DIR") or self.paths.cache_dir
        self.hifi = HifiPlayer(self.config, os.path.join(socket_dir, "pi-media-mpv.sock"),
                               lambda: "http://127.0.0.1:%d" % self.bound_port)
        player = PlayerController(self.hifi)
        router.add("GET", "/player/state", player.state)
        router.add("POST", "/player/cmd", player.command)
        router.add("GET", "/control/guest", guests.state)
        router.add("POST", "/control/guest", guests.hand_over)
        http = JsonHttp()
        self._add_podcast_routes(router, http)
        self._add_extmusic_routes(router, http)
        history = HistoryController(SearchHistory(self.db))
        router.add("GET", "/ext/history", history.entries)          # préfixe /ext/ : réservé au Pi par le contrôle d'accès
        router.add("POST", "/ext/history", history.change)
        self.remote_typing = RemoteTyping()
        self.phone_server = None
        remote = RemoteController(self.remote_typing, lambda: self.phone_server.port if self.phone_server else None)
        router.add("GET", "/ext/remote", remote.state)
        router.add("POST", "/ext/remote", remote.renew)
        router.add("POST", "/ext/remote/artists", remote.artists)
        self.queue_service = QueueService(PlayQueue(self.db))
        queue = QueueController(self.queue_service)
        router.add("GET", "/queue/state", queue.state)
        router.add("POST", "/queue/save", queue.save)
        router.add("POST", "/queue/take", queue.take)

    def _add_extmusic_routes(self, router, http):
        """Jamendo, YouTube et playlists locales : uniquement sur le Pi."""
        sources = [JamendoSource(http, self.config), YouTubeSource(http, self.config)]
        self.extmusic = ExtMusicService(self.config, sources, LocalPlaylists(self.db),
                                        UnplayableVideos(self.db))
        ext = ExtMusicController(self.extmusic)
        for name in ("status", "search", "playlists", "playlist", "favorites", "alternative"):
            router.add("GET", "/ext/" + name, getattr(ext, name))
        for name in ("settings", "create", "add", "remove", "delete", "favorite", "unplayable"):
            router.add("POST", "/ext/" + name, getattr(ext, name))

    def _add_podcast_routes(self, router, http):
        """Les podcasts n'existent que sur le Pi : le mode serveur ne les charge même pas."""
        hub = DirectoryHub(ItunesDirectory(http), PodcastIndexDirectory(http, self.config))
        service = PodcastService(self.config, hub, FeedReader(FeedFetcher()), PodcastLibrary(self.db))
        self.podcasts = service
        podcasts = PodcastController(self.config, service, self.pages)
        router.add("GET", "/podcasts", podcasts.page)
        for name in ("status", "home", "theme", "search", "show", "similar", "library"):
            router.add("GET", "/podcast-api/" + name, getattr(podcasts, name))
        for name in ("subscribe", "unsubscribe", "hide", "progress", "played", "language", "forget"):
            router.add("POST", "/podcast-api/" + name, getattr(podcasts, name))
        router.add("POST", "/podcast-api/key", podcasts.save_key)

    @staticmethod
    def _on_error(error):
        print("erreur : %r" % (error,), flush=True)
        return Reply.json({"error": "erreur interne"}, 500)

    # ---------- démarrage ----------
    def prepare(self):
        """Charge ce qui est sur disque et lance les tâches de fond."""
        self.cache.load()
        if self.config.server_mode:
            self.sessions.load()         # pas de préchargement global : chaque utilisateur préchauffe à sa connexion
        else:
            self.watcher.start()

    def make_server(self):
        server = ThreadedServer((self.config.bind_address, self.port), make_request_handler(self.http))
        self.bound_port = server.server_address[1]      # port réel (0 dans les tests : choisi par le système)
        return server

    def start_phone_server(self, port=None):
        """Saisie depuis le téléphone (Pi seulement) : petit serveur séparé, ouvert sur le réseau local."""
        if self.config.server_mode or self.config.get("phone_remote") is False:
            return None
        try:
            phone_queue = PhoneQueue(self.remote_typing, self._search_tracks, self.queue_service)
            self.phone_server = PhoneServer(self.remote_typing, self.paths.web_dir,
                                            port if port is not None else int(self.config.get("phone_port", PHONE_PORT)),
                                            phone_queue=phone_queue)
        except OSError as error:            # port déjà pris : le reste de l'application fonctionne quand même
            print("Saisie depuis le téléphone indisponible :", error, flush=True)
            return None
        return self.phone_server.start()

    def _search_tracks(self, text):
        """Recherche de titres dans la bibliothèque Subsonic (pour les téléphones)."""
        response = self.api.call_json("search3", [("query", text), ("songCount", "20"), ("artistCount", "0"), ("albumCount", "0")])
        tracks = []
        for raw in (response.get("searchResult3") or {}).get("song") or []:
            try:
                tracks.append(Track.from_api(raw))
            except ValueError:
                continue
        return tracks

    def run(self):
        self.prepare()
        self.start_phone_server()
        self.make_server().serve_forever()
