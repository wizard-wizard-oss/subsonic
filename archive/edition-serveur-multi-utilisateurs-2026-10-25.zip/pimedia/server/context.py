"""Utilisateur de la requête en cours (propre à chaque fil d'exécution)."""
import threading


class NotConfigured(Exception):
    """Aucun serveur Subsonic ou aucun utilisateur connu : impossible d'appeler Subsonic."""


class UserContext:
    """Identité utilisée pour parler à Subsonic. Le mot de passe n'est jamais conservé :
    on garde seulement le jeton Subsonic (md5 du mot de passe + sel) calculé à la connexion."""

    def __init__(self, user="", salt="", token="", settings=None):
        self.user = user
        self.salt = salt
        self.token = token
        self.settings = settings if settings is not None else {}

    def copy(self):
        return UserContext(self.user, self.salt, self.token, self.settings)

    @property
    def authenticated(self):
        return bool(self.user and self.token)


class ContextHolder:
    """Mémorise, pour chaque fil, l'utilisateur au nom duquel on travaille."""

    def __init__(self):
        self._local = threading.local()

    def current(self):
        ctx = getattr(self._local, "ctx", None)
        if ctx is None:
            ctx = self._local.ctx = UserContext()
        return ctx

    def bind(self, ctx):
        self._local.ctx = ctx

    def clear(self):
        self._local.ctx = UserContext()

    @property
    def user(self):
        return self.current().user

    def run_as(self, ctx, func, *args):
        """Exécute func au nom de ctx (utile dans un autre fil)."""
        self.bind(ctx)
        return func(*args)

    def spawn(self, func, *args, delay=0):
        """Lance func en tâche de fond, au nom de l'utilisateur courant. Les erreurs sont ignorées."""
        ctx = self.current().copy()

        def job():
            try:
                self.run_as(ctx, func, *args)
            except Exception:
                pass
        runner = threading.Timer(delay, job) if delay else threading.Thread(target=job)
        runner.daemon = True
        runner.start()
        return runner
