"""Couche HTTP : requête, réponse, routage et gestionnaire du serveur. Aucune logique métier ici."""
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .constants import LOOPBACK, SESSION_COOKIE


# ---------- requête ----------
class Request:
    """Ce qu'un contrôleur a besoin de savoir d'une requête, sans dépendre de http.server."""

    def __init__(self, method, target, headers, peer, rfile, connection=None):
        parts = urllib.parse.urlsplit(target)
        self.method = method
        self.path = parts.path
        self.query_string = parts.query
        self.query = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
        self.headers = headers
        self.peer = peer                     # adresse réelle de l'appelant (avant Apache)
        self.rfile = rfile
        self.connection = connection

    # --- paramètres ---
    def param(self, name, default=""):
        return dict(self.query).get(name, default)

    @property
    def content_length(self):
        try:
            return int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return 0

    def header(self, name, default=""):
        return self.headers.get(name) or default

    def json_body(self, limit=4096):
        """Corps JSON (limité en taille) ; un dictionnaire vide si absent ou invalide."""
        length = self.content_length
        if not length:
            return {}
        try:
            data = json.loads(self.rfile.read(min(length, limit)).decode("utf-8"))
        except (ValueError, OSError):
            return {}
        return data if isinstance(data, dict) else {}

    # --- identité de l'appelant ---
    @property
    def is_local(self):
        return self.peer in LOOPBACK

    @property
    def client_ip(self):
        """Adresse du visiteur. Derrière Apache (même machine), on fait confiance à X-Forwarded-For."""
        forwarded = self.header("X-Forwarded-For")
        if self.is_local and forwarded:
            return forwarded.split(",")[0].strip()
        return self.peer

    @property
    def session_id(self):
        for part in self.header("Cookie").split(";"):
            name, _, value = part.strip().partition("=")
            if name == SESSION_COOKIE:
                return value
        return None

    @property
    def is_https(self):
        return self.header("X-Forwarded-Proto") == "https"

    def same_origin(self):
        """Une requête venant d'une autre page web (en-tête Origin différent de l'hôte) est refusée."""
        origin = self.header("Origin")
        return not origin or urllib.parse.urlsplit(origin).netloc == self.header("Host")

    def set_timeout(self, seconds):
        """Délai d'inactivité de la connexion (un client qui ne lit plus ne bloque pas ce fil indéfiniment)."""
        try:
            self.connection.settimeout(seconds)
        except (AttributeError, OSError):
            pass


# ---------- réponses ----------
NO_STORE = {"Cache-Control": "no-store"}


class Reply:
    def __init__(self, status=200, body=b"", ctype="text/plain", headers=None):
        self.status = status
        self.body = body
        self.ctype = ctype
        self.headers = dict(headers or {})
        self.close_connection = False

    @classmethod
    def json(cls, data, status=200, headers=None):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        return cls(status, body, "application/json", dict(NO_STORE, **(headers or {})))

    @classmethod
    def raw_json(cls, body, status=200, headers=None):
        """Corps JSON déjà encodé."""
        return cls(status, body, "application/json; charset=utf-8", dict(NO_STORE, **(headers or {})))

    @classmethod
    def error(cls, status, code):
        return cls.json({"error": code}, status)

    @classmethod
    def not_found(cls):
        return cls(404, b"404", "text/plain")

    @classmethod
    def from_web_file(cls, web_file):
        return cls(web_file.status, web_file.body, web_file.ctype, web_file.headers)

    def write_to(self, handler):
        handler.send_response(self.status)
        if self.status != 304:
            handler.send_header("Content-Type", self.ctype)
            handler.send_header("Content-Length", str(len(self.body)))
        for name, value in self.headers.items():
            handler.send_header(name, value)
        handler.end_headers()
        if self.status != 304:
            handler.wfile.write(self.body)


class StreamReply(Reply):
    """Relaie une réponse Subsonic (audio) par morceaux, sans la garder en mémoire."""

    CHUNK = 65536
    COPIED_HEADERS = ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges")

    def __init__(self, upstream, status):
        super().__init__(status)
        self.upstream = upstream
        self.has_length = bool(upstream.headers.get("Content-Length"))
        self.close_connection = not self.has_length

    def write_to(self, handler):
        handler.send_response(self.status)
        for name in self.COPIED_HEADERS:
            value = self.upstream.headers.get(name)
            if value:
                handler.send_header(name, value)
        if not self.has_length:
            handler.send_header("Connection", "close")
        handler.end_headers()
        self._pump(handler.wfile)

    def _pump(self, out):
        try:
            while True:
                chunk = self.upstream.read(self.CHUNK)
                if not chunk:
                    break
                out.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            self.upstream.close()


# ---------- routage ----------
class Router:
    """Associe (méthode, chemin) à une fonction de contrôleur : chemin exact, ou préfixe (« /static/… »)."""

    def __init__(self):
        self._exact = {}
        self._prefixes = []

    def add(self, method, path, handler):
        self._exact[(method, path)] = handler

    def add_prefix(self, method, prefix, handler):
        self._prefixes.append((method, prefix, handler))

    def find(self, method, path):
        handler = self._exact.get((method, path))
        if handler:
            return handler
        for route_method, prefix, route_handler in self._prefixes:
            if route_method == method and path.startswith(prefix):
                return route_handler
        return None


# ---------- application HTTP ----------
class HttpApp:
    """Chaîne de traitement d'une requête : en-têtes de sécurité, contrôle d'accès, contrôleur."""

    def __init__(self, router, gate, security_headers, holder, on_error):
        self.router = router
        self.gate = gate
        self.security_headers = security_headers
        self.holder = holder
        self.on_error = on_error             # fonction (exception) -> Reply

    def handle(self, request):
        self.holder.clear()
        try:
            reply = self.gate.check(request) or self._dispatch(request)
        except Exception as error:           # noqa: BLE001 - toute erreur devient une réponse propre
            reply = self.on_error(error)
        for name, value in self.security_headers.for_reply().items():
            reply.headers.setdefault(name, value)
        return reply

    def _dispatch(self, request):
        handler = self.router.find(request.method, request.path)
        return handler(request) if handler else Reply.not_found()


def make_request_handler(app):
    """Fabrique la classe de gestionnaire http.server liée à l'application."""

    class RequestHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        timeout = 300          # une connexion silencieuse est fermée (évite d'accumuler des connexions mortes)

        def log_message(self, *args):
            pass

        def _serve(self, method):
            request = Request(method, self.path, self.headers, self.client_address[0], self.rfile, self.connection)
            reply = app.handle(request)
            if reply.close_connection:
                self.close_connection = True
            reply.write_to(self)

        def do_GET(self):
            self._serve("GET")

        def do_POST(self):
            self._serve("POST")

    return RequestHandler


class ThreadedServer(ThreadingHTTPServer):
    daemon_threads = True
