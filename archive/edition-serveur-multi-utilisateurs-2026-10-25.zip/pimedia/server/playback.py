"""Lecture haute fidélité sur le Pi : le son est joué par mpv au lieu du navigateur.

Chromium convertit tout en 48 kHz ; mpv envoie chaque fichier à sa fréquence d'origine (44,1, 96, 192 kHz…)
et enchaîne les titres sans blanc. La page garde sa file d'attente et pilote mpv comme un élément audio.

mpv tourne en arrière-plan, piloté par son interface JSON (socket Unix, une commande par ligne)."""
import itertools
import json
import os
import socket
import subprocess
import threading
import time
import urllib.parse

CLIENT_NAME = "pi-media-hifi"          # nom du flux audio : le menu le reconnaît comme « lecteur de la page »
OBSERVED = ("time-pos", "duration", "pause", "idle-active", "playlist-pos", "playlist-count")
STREAM_PATH = "/rest/stream.view"


def mpv_command(socket_path):
    return ["mpv", "--idle=yes", "--no-video", "--no-terminal", "--audio-display=no",
            "--gapless-audio=yes", "--prefetch-playlist=yes", "--cache=yes",
            "--audio-client-name=" + CLIENT_NAME, "--input-ipc-server=" + socket_path]


class MpvError(Exception):
    pass


class MpvConnection:
    """Un processus mpv et sa connexion de commande. Redémarre mpv s'il s'est arrêté."""

    def __init__(self, socket_path, command=None, on_event=None):
        self.socket_path = socket_path
        self.command = command or mpv_command(socket_path)
        self.on_event = on_event or (lambda event: None)
        self.process = None
        self.sock = None
        self._lock = threading.Lock()
        self._ids = itertools.count(1)
        self._waiting = {}

    def ensure(self):
        with self._lock:
            if self.sock is not None and self.process is not None and self.process.poll() is None:
                return
            self._start()

    def _start(self):
        if self.sock is not None:
            self.sock.close()
            self.sock = None
        if os.path.exists(self.socket_path):
            os.unlink(self.socket_path)
        try:
            self.process = subprocess.Popen(self.command, stdin=subprocess.DEVNULL,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as error:
            raise MpvError("mpv introuvable (%s)" % error)
        deadline = time.time() + 5
        while time.time() < deadline:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                sock.connect(self.socket_path)
                self.sock = sock
                threading.Thread(target=self._read, args=(sock,), daemon=True).start()
                for number, name in enumerate(OBSERVED, start=1):
                    self._send({"command": ["observe_property", number, name]})
                return
            except OSError:
                sock.close()
                time.sleep(0.1)
        raise MpvError("mpv ne répond pas")

    def _send(self, message):
        self.sock.sendall((json.dumps(message) + "\n").encode("utf-8"))

    def call(self, *args, timeout=3):
        """Commande mpv ; renvoie sa donnée, ou lève MpvError."""
        self.ensure()
        request_id = next(self._ids)
        done = threading.Event()
        slot = {"event": done}
        self._waiting[request_id] = slot
        try:
            with self._lock:
                self._send({"command": list(args), "request_id": request_id})
        except OSError as error:
            self._waiting.pop(request_id, None)
            self.sock = None
            raise MpvError(str(error))
        if not done.wait(timeout):
            self._waiting.pop(request_id, None)
            raise MpvError("mpv ne répond pas")
        reply = slot["reply"]
        if reply.get("error") not in (None, "success"):
            raise MpvError(reply["error"])
        return reply.get("data")

    def _read(self, sock):
        buffer = b""
        while True:
            try:
                chunk = sock.recv(65536)
            except OSError:
                break
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                try:
                    message = json.loads(line.decode("utf-8"))
                except ValueError:
                    continue
                slot = self._waiting.pop(message.get("request_id"), None) if "request_id" in message else None
                if slot is not None:
                    slot["reply"] = message
                    slot["event"].set()
                elif "event" in message:
                    self.on_event(message)
        if self.sock is sock:
            self.sock = None

    def stop(self):
        if self.sock is not None:
            self.sock.close()
            self.sock = None
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(2)
            except subprocess.TimeoutExpired:
                self.process.kill()


class HifiPlayer:
    """État de lecture que la page interroge, et commandes qu'elle envoie."""

    def __init__(self, config, socket_path, local_base, command=None):
        self.config = config
        self.local_base = local_base           # fonction : « http://127.0.0.1:8099 » (port réel du serveur)
        self.mpv = MpvConnection(socket_path, command, self._on_event)
        self._lock = threading.Lock()
        self.props = {}
        self.current = ""                      # adresse (telle que la page la connaît) du titre en cours
        self.queued = ""                       # titre suivant préchargé (enchaînement sans blanc)
        self.ended = 0                         # compteurs : la page voit qu'un titre s'est fini ou a échoué
        self.errors = 0

    # ---------- réglage ----------
    @property
    def enabled(self):
        return bool(self.config.get("hifi_playback"))

    def set_enabled(self, on):
        self.config.update(hifi_playback=bool(on))
        if not on:
            self._safe("stop")

    # ---------- état ----------
    def state(self):
        with self._lock:
            props = dict(self.props)
            return {"enabled": self.enabled, "url": self.current, "queued": self.queued,
                    "pos": props.get("time-pos") or 0, "duration": props.get("duration") or 0,
                    "paused": bool(props.get("pause")) or bool(props.get("idle-active", True)),
                    "idle": bool(props.get("idle-active", True)), "ended": self.ended, "errors": self.errors}

    def _on_event(self, event):
        with self._lock:
            if event["event"] == "property-change":
                self.props[event["name"]] = event.get("data")
            elif event["event"] == "end-file":
                reason = event.get("reason")
                if reason == "error":
                    self.errors += 1
                elif reason == "eof":
                    self.ended += 1
                    if self.queued:                # mpv enchaîne seul sur le titre préchargé
                        self.current, self.queued = self.queued, ""

    # ---------- commandes ----------
    def resolve(self, url):
        """Adresse donnée par la page -> adresse jouée par mpv. Seuls le flux Subsonic du relais local
        et les adresses web publiques (radio, Jamendo) sont acceptés."""
        parts = urllib.parse.urlsplit(url or "")
        if not parts.scheme and parts.path == STREAM_PATH:
            return self.local_base() + url
        if parts.scheme in ("http", "https") and parts.hostname and parts.hostname not in ("localhost", "127.0.0.1"):
            return url
        raise ValueError("adresse refusée")

    def load(self, url):
        target = self.resolve(url)
        with self._lock:
            already_playing = url == self.current and url and not self.props.get("idle-active", True)
            if not already_playing:
                self.current, self.queued = url, ""
        if not already_playing:                     # sinon : enchaîné tout seul par mpv, rien à recharger
            self.mpv.call("loadfile", target, "replace")
        self.mpv.call("set_property", "pause", False)

    def preload(self, url):
        """Titre suivant ajouté derrière le titre en cours : mpv l'enchaîne sans blanc."""
        if not url:
            return self.drop_preload()
        target = self.resolve(url)
        with self._lock:
            if url == self.queued:
                return
            self.queued = url
        self._safe("playlist-clear")               # retire tout sauf le titre en cours (ancien préchargement, titres joués)
        self.mpv.call("loadfile", target, "append")

    def drop_preload(self):
        with self._lock:
            self.queued = ""
        self._safe("playlist-clear")

    def pause(self, paused):
        self.mpv.call("set_property", "pause", bool(paused))

    def seek(self, seconds):
        self.mpv.call("seek", float(seconds), "absolute")

    def volume(self, level):
        self.mpv.call("set_property", "volume", max(0, min(100, float(level))))

    def stop(self):
        with self._lock:
            self.current = self.queued = ""
        self._safe("stop")

    def _safe(self, *args):
        try:
            self.mpv.call(*args)
        except MpvError:
            pass
