"""Musique d'ailleurs (écran du Raspberry Pi seulement) : Jamendo, YouTube, playlists locales."""
