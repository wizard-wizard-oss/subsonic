"""Connexion, déconnexion, identité et réglages de l'utilisateur."""
from ..constants import BROWSE_MODES, QUALITIES, SESSION_COOKIE
from ..transport import Reply


class SettingsService:
    """Réglages (mode de navigation, qualité) : par utilisateur en mode serveur, globaux sur le Pi."""

    def __init__(self, config, browse, user_settings, holder):
        self.config = config
        self.browse = browse
        self.user_settings = user_settings
        self.holder = holder

    def current(self):
        if self.config.server_mode:
            return dict(self.user_settings.get(self.holder.user))
        return {"browse_mode": self.browse.current(), "quality": self.config.get("quality", "raw")}

    def update(self, changes):
        if self.config.server_mode:
            self.user_settings.update(self.holder.user, changes)
        else:
            self._update_pi(changes)
        return self.current()

    def _update_pi(self, changes):
        if changes.get("browse_mode") in BROWSE_MODES:
            self.browse.set_pi_mode(changes["browse_mode"])
        if changes.get("quality") in QUALITIES:
            self.config.update(quality=changes["quality"])


def session_cookie(value, max_age, secure):
    flags = "; Secure" if secure else ""
    return {"Set-Cookie": "%s=%s; Path=/; Max-Age=%d; HttpOnly; SameSite=Lax%s" % (SESSION_COOKIE, value, max_age, flags)}


class SessionController:
    def __init__(self, config, accounts, sessions, upload_policy, settings, holder, warm_up):
        self.config = config
        self.accounts = accounts
        self.sessions = sessions
        self.upload_policy = upload_policy
        self.settings = settings
        self.holder = holder
        self.warm_up = warm_up

    def me(self, request):
        if not self.config.server_mode:
            return Reply.json({"server": False})
        user = self.holder.user
        if not user:
            return Reply.json({"server": True, "error": "auth"}, 401)
        return Reply.json({"server": True, "user": user, "admin": self.accounts.is_admin(user),
                           "upload": self.upload_policy.can_upload(user),
                           "upload_max_mb": self.config.upload_max_bytes // 1048576})

    def login(self, request):
        if not request.same_origin():
            return Reply.error(403, "origin")
        body = request.json_body()
        user, password = str(body.get("user", "")).strip(), str(body.get("pass", ""))
        status, message, sid = self.accounts.login(request.client_ip, user, password)
        if not sid:
            return Reply.json({"error": message}, status)
        self.holder.bind(self.accounts.context_for(sid))
        self.warm_up.trigger(force=True)
        cookie = session_cookie(sid, self.sessions.max_age, request.is_https)
        return Reply.json({"ok": True, "user": user}, headers=cookie)

    def logout(self, request):
        if not request.same_origin():
            return Reply.error(403, "origin")
        self.accounts.logout(request.session_id)
        return Reply.json({"ok": True}, headers=session_cookie("", 0, request.is_https))

    def settings_page(self, request):
        changes = dict(request.query)
        return Reply.json(self.settings.update(changes) if changes else self.settings.current())
