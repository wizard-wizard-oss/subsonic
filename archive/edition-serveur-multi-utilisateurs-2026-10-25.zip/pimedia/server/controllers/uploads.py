"""Envoi de musique (mode serveur)."""
from ..transport import Reply
from ..uploads import UploadRefused


class UploadController:
    RECEIVE_TIMEOUT = 120

    def __init__(self, service, holder):
        self.service = service
        self.holder = holder

    def receive(self, request):
        """POST /upload?name=…&artist=… : le corps est le fichier ZIP."""
        if not request.same_origin():
            return Reply.error(403, "refus")
        request.set_timeout(self.RECEIVE_TIMEOUT)
        try:
            job_id = self.service.accept(self.holder.user, request.rfile, request.content_length,
                                         request.param("name", "envoi.zip"), request.param("artist"))
        except UploadRefused as refusal:
            reply = Reply.json({"error": refusal.message}, refusal.status)
            reply.close_connection = True       # le corps de la requête n'a pas été lu
            return reply
        return Reply.json({"id": job_id}, 202)

    def listing(self, request):
        return Reply.json(self.service.jobs_of(self.holder.user))
