"""Mode serveur : sessions, limitation des essais de connexion et réglages par utilisateur."""
import json
import os
import secrets
import threading
import time

from .constants import BROWSE_MODES, QUALITIES
from .context import UserContext


# ---------- sessions ----------
class Session:
    def __init__(self, user, salt, token, expires):
        self.user = user
        self.salt = salt
        self.token = token
        self.expires = expires

    def to_dict(self):
        return {"user": self.user, "salt": self.salt, "token": self.token, "exp": self.expires}

    @classmethod
    def from_dict(cls, data):
        return cls(data["user"], data["salt"], data["token"], data.get("exp", 0))

    def valid(self, now=None):
        return self.expires > (now or time.time())


class SessionStore:
    """Sessions ouvertes, conservées dans un fichier (lisible par le seul propriétaire) pour survivre à un redémarrage.
    Aucun mot de passe : seulement le jeton Subsonic (md5 du mot de passe + sel)."""

    def __init__(self, path, days):
        self.path = path
        self.days = days
        self._sessions = {}
        self._lock = threading.Lock()

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return
        for sid, raw in data.items():
            try:
                session = Session.from_dict(raw)
            except (KeyError, TypeError):
                continue
            if session.valid():
                self._sessions[sid] = session

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({sid: s.to_dict() for sid, s in self._sessions.items()}, f)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def create(self, user, salt, token):
        """Ouvre une session et retourne son identifiant (celui du cookie)."""
        sid = secrets.token_urlsafe(32)
        with self._lock:
            self._drop_expired()
            self._sessions[sid] = Session(user, salt, token, time.time() + self.days * 86400)
            self._save()
        return sid

    def get(self, sid):
        session = self._sessions.get(sid or "")
        return session if session and session.valid() else None

    def delete(self, sid):
        with self._lock:
            if self._sessions.pop(sid or "", None) is not None:
                self._save()

    def _drop_expired(self):
        for sid in [k for k, s in self._sessions.items() if not s.valid()]:
            self._sessions.pop(sid, None)

    @property
    def max_age(self):
        return self.days * 86400


# ---------- essais de connexion ----------
class LoginThrottle:
    """Au plus 8 échecs par adresse IP et par période de 10 minutes."""

    MAX_FAILURES = 8
    WINDOW = 600
    CLEAN_ABOVE = 2000

    def __init__(self):
        self._failures = {}
        self._lock = threading.Lock()

    def blocked(self, ip):
        with self._lock:
            self._forget_old(ip)
            return len(self._failures.get(ip, [])) >= self.MAX_FAILURES

    def record_failure(self, ip):
        with self._lock:
            self._failures.setdefault(ip, []).append(time.time())

    def reset(self, ip):
        with self._lock:
            self._failures.pop(ip, None)

    def _forget_old(self, ip):
        now = time.time()
        if len(self._failures) > self.CLEAN_ABOVE:
            for key in [k for k, v in self._failures.items() if not v or now - v[-1] > self.WINDOW]:
                self._failures.pop(key, None)
        self._failures[ip] = [t for t in self._failures.get(ip, []) if now - t < self.WINDOW]


# ---------- réglages par utilisateur ----------
USER_DEFAULTS = {"browse_mode": "folders", "quality": "raw"}
USER_CHOICES = {"browse_mode": BROWSE_MODES, "quality": QUALITIES}


# ---------- comptes ----------
class Accounts:
    """Qui est connecté, qui est administrateur, et connexion/déconnexion."""

    def __init__(self, config, client, sessions, throttle, settings):
        self.config = config
        self.client = client
        self.sessions = sessions
        self.throttle = throttle
        self.settings = settings

    def is_admin(self, user):
        return bool(user) and user.lower() in self.config.admins

    def context_for(self, sid):
        """Identité liée à un cookie de session, ou None."""
        session = self.sessions.get(sid)
        if session is None:
            return None
        return UserContext(session.user, session.salt, session.token, self.settings.get(session.user))

    def login(self, ip, user, password):
        """Retourne (statut HTTP, message d'erreur ou None, identifiant de session ou None)."""
        if self.throttle.blocked(ip):
            return 429, "Trop d’essais, réessayez dans 10 minutes", None
        verified = self.client.verify_login(user, password)
        if not verified:
            self.throttle.record_failure(ip)
            return 401, "Identifiant ou mot de passe incorrect", None
        self.throttle.reset(ip)
        return 200, None, self.sessions.create(user, verified[0], verified[1])

    def logout(self, sid):
        self.sessions.delete(sid)
