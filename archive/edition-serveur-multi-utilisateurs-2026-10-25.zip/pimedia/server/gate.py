"""Contrôle d'accès du mode serveur et en-têtes de sécurité."""
from .constants import CSRF_HEADER, CSRF_VALUE, MEDIA_ENDPOINTS, PUBLIC_PATHS
from .transport import Reply

PI_ONLY_PATHS = frozenset(("/control/send", "/control/poll", "/control/volume", "/control/awake",
                           "/control/quit", "/control/mode", "/control/guest", "/podcasts"))
PI_ONLY_PREFIXES = ("/podcast-api/", "/ext/", "/player/", "/queue/")
HOME_PATHS = frozenset(("/", "/index.html"))
STATIC_PREFIX = "/static/"

CONTENT_SECURITY_POLICY = (
    # aucun script en ligne : seuls les fichiers de ce site sont exécutés
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: https://upload.wikimedia.org; media-src 'self' blob:; connect-src 'self'; "
    "frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")


class SecurityHeaders:
    def __init__(self, config):
        self.config = config

    def for_reply(self):
        """En-têtes ajoutés à toutes les réponses."""
        return {"X-Content-Type-Options": "nosniff"} if self.config.server_mode else {}

    def for_index(self):
        """En-têtes de la page d'accueil."""
        if not self.config.server_mode:
            return {}
        return {"X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                "Content-Security-Policy": CONTENT_SECURITY_POLICY}


class AccessGate:
    """Premier filtre de chaque requête. Retourne une réponse de refus, ou None pour laisser passer.
    Hors mode serveur (écran du Raspberry Pi, déjà protégé par le réseau local), tout passe."""

    def __init__(self, config, accounts, holder, warm_up):
        self.config = config
        self.accounts = accounts
        self.holder = holder
        self.warm_up = warm_up              # WarmUpThrottle

    def check(self, request):
        if not self.config.server_mode:
            return None
        path = request.path
        if path.startswith(STATIC_PREFIX):
            return None                      # CSS/JS : aucun secret, nécessaires pour afficher la page de connexion
        refusal = self._cheap_refusal(request)
        if refusal:
            return refusal
        context = self.accounts.context_for(request.session_id)
        if context:
            self.holder.bind(context)
        return self._authorize(request, bool(context))

    def _cheap_refusal(self, request):
        """Refus qui ne demandent aucune connaissance de l'utilisateur."""
        if request.header("Sec-Fetch-Site") == "cross-site" and request.path not in HOME_PATHS:
            return Reply.error(403, "cross-site")
        if request.path in PI_ONLY_PATHS or request.path.startswith(PI_ONLY_PREFIXES):
            return Reply.not_found()
        return None

    def _authorize(self, request, logged_in):
        public = request.path in PUBLIC_PATHS
        if not logged_in and not public:
            return Reply.json({"error": "auth"}, 401)
        if not public and not self._is_media(request) and request.header(CSRF_HEADER) != CSRF_VALUE:
            # une page tierce ne peut pas ajouter cet en-tête : impossible de déclencher une action à l'insu de l'utilisateur
            return Reply.error(403, "refus")
        if logged_in and request.path.startswith("/rest/"):
            self.warm_up.trigger()
        return None

    @staticmethod
    def _is_media(request):
        """Images et audio sont chargés par le navigateur lui-même, qui ne peut pas ajouter l'en-tête anti-CSRF."""
        if not request.path.startswith("/rest/"):
            return False
        endpoint = request.path.rsplit("/", 1)[-1].split(".")[0]
        return endpoint in MEDIA_ENDPOINTS
