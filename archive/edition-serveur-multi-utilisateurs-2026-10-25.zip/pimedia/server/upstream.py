"""Accès HTTP au serveur Subsonic."""
import hashlib
import json
import secrets
import urllib.error
import urllib.parse
import urllib.request

from .constants import API_VERSION, AUTH_PARAMS, BINARY_ENDPOINTS, CLIENT_NAME
from .context import NotConfigured


def make_token(password):
    """Jeton d'authentification Subsonic : (sel, md5(mot de passe + sel))."""
    salt = secrets.token_hex(8)
    return salt, hashlib.md5((password + salt).encode()).hexdigest()


class SubsonicClient:
    def __init__(self, config, holder):
        self.config = config
        self.holder = holder

    # --- identité ---
    def credentials(self):
        """(utilisateur, sel, jeton) à utiliser pour la requête en cours."""
        if self.config.server_mode:
            ctx = self.holder.current()
            if not ctx.authenticated:
                raise NotConfigured()
            return ctx.user, ctx.salt, ctx.token
        user, password = self.config.get("subsonic_user", ""), self.config.get("subsonic_pass", "")
        if not user:
            raise NotConfigured()
        salt, token = make_token(password)
        return user, salt, token

    # --- requêtes ---
    def build_url(self, endpoint, params, credentials):
        user, salt, token = credentials
        items = [(k, v) for k, v in params if k not in AUTH_PARAMS and not k.startswith("_")]
        items += [("u", user), ("t", token), ("s", salt), ("v", API_VERSION), ("c", CLIENT_NAME)]
        if endpoint not in BINARY_ENDPOINTS and "f" not in dict(items):
            items.append(("f", "json"))
        return "%s/rest/%s.view?%s" % (self.config.subsonic_url, endpoint, urllib.parse.urlencode(items))

    def open(self, endpoint, params, headers=None, timeout=30):
        """Ouvre une réponse Subsonic (une réponse d'erreur HTTP est retournée comme les autres)."""
        if not self.config.subsonic_url:
            raise NotConfigured()
        request = urllib.request.Request(self.build_url(endpoint, params, self.credentials()))
        for name, value in (headers or {}).items():
            request.add_header(name, value)
        try:
            return urllib.request.urlopen(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            return error

    def verify_login(self, user, password):
        """Teste un identifiant. Retourne (sel, jeton) s'il est valide, sinon None."""
        if not self.config.subsonic_url or not user or not password:
            return None
        salt, token = make_token(password)
        url = self.build_url("ping", [], (user, salt, token))
        try:
            with urllib.request.urlopen(url, timeout=15) as response:
                valid = json.loads(response.read().decode())["subsonic-response"]["status"] == "ok"
        except (OSError, ValueError, KeyError):
            return None
        return (salt, token) if valid else None

    def trigger_scan(self):
        """Demande à Subsonic de scanner sa bibliothèque (réservé parfois aux administrateurs)."""
        try:
            response = self.open("startScan", [], timeout=30)
            response.read()
            response.close()
        except Exception:
            pass
