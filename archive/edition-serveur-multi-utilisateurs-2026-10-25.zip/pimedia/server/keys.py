"""Mode de navigation (dossiers ou tags) et construction des clés de cache."""
import hashlib
import urllib.parse

from .constants import BROWSE_MODES, FOLDER_ENDPOINTS


class BrowseMode:
    """Classement de la bibliothèque : « folders » (arborescence, comme l'interface Subsonic d'origine)
    ou « tags » (tags ID3). Sur le Pi : un réglage global ; en mode serveur : un réglage par utilisateur."""

    def __init__(self, config, holder):
        self.config = config
        self.holder = holder
        saved = config.get("browse_mode")
        self._pi_mode = saved if saved in BROWSE_MODES else "folders"

    def current(self):
        if self.config.server_mode:
            return self.holder.current().settings.get("browse_mode", "folders")
        return self._pi_mode

    def set_pi_mode(self, mode):
        if mode in BROWSE_MODES:
            self._pi_mode = mode
            self.config.update(browse_mode=mode)

    def uses_folders(self, endpoint):
        return self.current() == "folders" and endpoint in FOLDER_ENDPOINTS


class CacheKeys:
    """Clé de cache d'un appel. Elle tient compte du mode de navigation et, en mode serveur, de l'utilisateur
    (favoris et notes sont personnels) — sauf pour les pochettes et les informations externes."""

    SHARED_PREFIX = "ext-"

    def __init__(self, config, holder, browse):
        self.config = config
        self.holder = holder
        self.browse = browse

    def for_call(self, endpoint, params):
        suffix = "|F2" if self.browse.uses_folders(endpoint) else ""
        if self.config.server_mode and self._is_personal(endpoint):
            suffix += "|u:" + self.holder.user
        raw = endpoint + "?" + urllib.parse.urlencode(sorted(params)) + suffix
        return hashlib.sha1(raw.encode()).hexdigest()

    def _is_personal(self, endpoint):
        return endpoint != "getCoverArt" and not endpoint.startswith(self.SHARED_PREFIX)

    def owner(self):
        """Utilisateur à enregistrer avec une entrée de cache (vide hors mode serveur)."""
        return self.holder.user if self.config.server_mode else ""

    def is_mine(self, meta):
        """Entrée de cache de l'utilisateur courant (toujours vrai hors mode serveur)."""
        return not self.config.server_mode or meta.get("u") == self.holder.user
