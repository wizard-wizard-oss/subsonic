"""Réglages de chaque utilisateur (mode serveur) : classement et qualité."""
import json
import threading

class UserSettings:
    """defaults : {réglage: valeur par défaut} ; allowed : {réglage: valeurs acceptées}."""

    def __init__(self, db, defaults, allowed):
        self.db = db
        self.DEFAULTS = dict(defaults)
        self.VALID = dict(allowed)
        self._cache = {}
        self._lock = threading.Lock()

    def get(self, user):
        """Dictionnaire de réglages de l'utilisateur (le même objet à chaque appel, mis à jour sur place)."""
        with self._lock:
            if user not in self._cache:
                settings = dict(self.DEFAULTS)
                for row in self.db.query("SELECT key, value FROM user_settings WHERE username = ?", (user,)):
                    if row["key"] in self.DEFAULTS:
                        settings[row["key"]] = json.loads(row["value"])
                self._cache[user] = settings
            return self._cache[user]

    def update(self, user, changes):
        """Applique les valeurs valides de changes, enregistre, et retourne les réglages."""
        settings = self.get(user)
        valid = {name: changes[name] for name, allowed in self.VALID.items() if changes.get(name) in allowed}
        with self._lock, self.db.transaction() as conn:
            for name, value in valid.items():
                conn.execute("INSERT INTO user_settings (username, key, value) VALUES (?, ?, ?) ON CONFLICT (username, key) "
                             "DO UPDATE SET value = excluded.value", (user, name, json.dumps(value)))
                settings[name] = value
        return settings
