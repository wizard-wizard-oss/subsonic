#!/usr/bin/env python3
"""Fabrique l'archive à déployer sur le Pi : dist/pi-media-<version>.tar.gz (+ une copie de deploy.sh).

Usage : python3 deploy/build_archive.py [version]      (par défaut : date et heure, ex. 2026.10.25-1530)
Contenu : le code et les fichiers nécessaires, jamais de données ni de secrets (.env, *.db, config.json)."""
import io
import os
import shutil
import sys
import tarfile
import time

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INCLUDED = ("pimedia", "web", "i18n", "deploy", "launcher.py", "subsonic-web.py", ".env.example")
EXCLUDED_DIRS = {"__pycache__", "dist"}
EXCLUDED_SUFFIXES = (".pyc", ".db", ".db-wal", ".db-shm", ".importe")
EXCLUDED_NAMES = {".env", "config.json"}


def wanted(path):
    name = os.path.basename(path)
    return name not in EXCLUDED_NAMES and not name.endswith(EXCLUDED_SUFFIXES)


def files():
    for entry in INCLUDED:
        full = os.path.join(PROJECT, entry)
        if os.path.isfile(full):
            yield entry
            continue
        for directory, subdirs, names in os.walk(full):
            subdirs[:] = sorted(d for d in subdirs if d not in EXCLUDED_DIRS)
            for name in sorted(names):
                relative = os.path.relpath(os.path.join(directory, name), PROJECT)
                if wanted(relative):
                    yield relative


def build(version):
    dist = os.path.join(PROJECT, "dist")
    os.makedirs(dist, exist_ok=True)
    archive = os.path.join(dist, "pi-media-%s.tar.gz" % version)
    with tarfile.open(archive, "w:gz") as tar:
        for relative in files():
            tar.add(os.path.join(PROJECT, relative), arcname=relative, recursive=False)
        data = (version + "\n").encode()
        info = tarfile.TarInfo("VERSION")
        info.size, info.mtime, info.mode = len(data), int(time.time()), 0o644
        tar.addfile(info, io.BytesIO(data))
    shutil.copy(os.path.join(PROJECT, "deploy", "deploy.sh"), os.path.join(dist, "deploy.sh"))
    shutil.copy(os.path.join(PROJECT, "deploy", "bin", "migration.sh"), os.path.join(dist, "migration.sh"))
    return archive


if __name__ == "__main__":
    print(build(sys.argv[1] if len(sys.argv) > 1 else time.strftime("%Y.%m.%d-%H%M")))
