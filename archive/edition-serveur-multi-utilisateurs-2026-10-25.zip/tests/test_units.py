"""Tests unitaires : fonctions pures et petites classes, sans réseau."""
import io
import os
import tempfile
import time
import unittest
import zipfile

from pimedia.server.auth import USER_CHOICES, USER_DEFAULTS, LoginThrottle, Session, SessionStore
from pimedia.storage.database import Database
from pimedia.storage.users import UserSettings
from pimedia.server.cache import JsonCache
from pimedia.server.external import clean_title, first_artist, sentences
from pimedia.server.folders import as_list, merge_artists, normalize_name, to_album
from pimedia.server.policy import CachePolicy
from pimedia.server.transport import Request, Router
from pimedia.server.uploads import FolderMatcher, ZipPlanner, clean_part, magic_ok
from pimedia.server.upstream import make_token
from pimedia.server.webfiles import etag_matches


class NamesTest(unittest.TestCase):
    def test_normalize_ignores_case_accents_the_and_punctuation(self):
        self.assertEqual(normalize_name("The Beatles"), normalize_name("beatles"))
        self.assertEqual(normalize_name("Björk"), normalize_name("BJORK"))
        self.assertEqual(normalize_name("AC/DC"), "acdc")

    def test_merge_artists_joins_ids_of_the_same_name(self):
        merged = merge_artists([{"id": "1", "name": "ABBA"}, {"id": "2", "name": "Abba"}, {"id": "3", "name": "Björk"}])
        self.assertEqual([a["id"] for a in merged], ["1|2", "3"])

    def test_merge_does_not_repeat_an_id(self):
        merged = merge_artists([{"id": "1", "name": "A"}, {"id": "1", "name": "a"}])
        self.assertEqual(merged[0]["id"], "1")

    def test_as_list(self):
        self.assertEqual(as_list(None), [])
        self.assertEqual(as_list({"a": 1}), [{"a": 1}])
        self.assertEqual(as_list([1, 2]), [1, 2])

    def test_to_album_drops_missing_fields(self):
        album = to_album({"id": "x", "title": "T", "parent": "p"})
        self.assertEqual(album["name"], "T")
        self.assertEqual(album["coverArt"], "x")
        self.assertNotIn("year", album)


class TextTest(unittest.TestCase):
    def test_clean_title_removes_noise(self):
        self.assertEqual(clean_title("Song (Remastered 2011)"), "Song")
        self.assertEqual(clean_title("Song - Live at Wembley"), "Song")
        self.assertEqual(clean_title("Song feat. Someone"), "Song")
        self.assertEqual(clean_title("Plain"), "Plain")

    def test_first_artist_keeps_daft(self):
        self.assertEqual(first_artist("Daft Punk"), "Daft Punk")
        self.assertEqual(first_artist("A feat. B"), "A")

    def test_sentences_filters_by_length_and_strips_html(self):
        text = "<b>Court.</b> " + "Ceci est une phrase assez longue pour être retenue par le filtre. " * 1
        found = sentences(text, 5)
        self.assertEqual(len(found), 1)
        self.assertNotIn("<", found[0])


class MagicBytesTest(unittest.TestCase):
    def test_accepts_real_signatures(self):
        self.assertTrue(magic_ok(".mp3", b"ID3\x04" + b"0" * 20))
        self.assertTrue(magic_ok(".flac", b"fLaC" + b"0" * 20))
        self.assertTrue(magic_ok(".png", b"\x89PNG\r\n"))
        self.assertTrue(magic_ok(".wav", b"RIFF\x00\x00\x00\x00WAVE"))

    def test_refuses_disguised_files(self):
        self.assertFalse(magic_ok(".mp3", b"MZ\x90\x00 executable"))
        self.assertFalse(magic_ok(".flac", b"<?php echo 1;"))
        self.assertFalse(magic_ok(".exe", b"MZ"))
        self.assertFalse(magic_ok(".lrc", b"abc\x00def"))

    def test_clean_part_removes_forbidden_characters(self):
        self.assertEqual(clean_part('a<b>:c?'), "a_b__c_")
        self.assertEqual(clean_part("name. "), "name")


def build_zip(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        for name, data in entries:
            archive.writestr(name, data)
    return zipfile.ZipFile(io.BytesIO(buffer.getvalue()))


class ZipPlannerTest(unittest.TestCase):
    MP3 = b"ID3" + b"0" * 30

    def plan(self, entries, artist="", name="envoi.zip", limit=10 ** 9):
        archive = build_zip(entries)
        return ZipPlanner(limit).plan(archive.infolist(), artist, name)

    def paths(self, plan):
        return sorted("/".join(dirs + [name]) for _, dirs, name in plan.items)

    def test_artist_album_title_is_kept(self):
        plan = self.plan([("ABBA/Arrival/01.mp3", self.MP3)])
        self.assertEqual(self.paths(plan), ["ABBA/Arrival/01.mp3"])
        self.assertFalse(plan.unsorted)

    def test_loose_files_go_to_unsorted(self):
        plan = self.plan([("01.mp3", self.MP3)], name="Mon album.zip")
        self.assertEqual(self.paths(plan), ["À classer/Mon album/01.mp3"])
        self.assertTrue(plan.unsorted)

    def test_given_artist_is_used(self):
        plan = self.plan([("Album/01.mp3", self.MP3)], artist="Björk")
        self.assertEqual(self.paths(plan), ["Björk/Album/01.mp3"])

    def test_dangerous_entries_are_dropped(self):
        plan = self.plan([("../evil.mp3", self.MP3), ("/abs/evil.mp3", self.MP3), ("C:/x/evil.mp3", self.MP3),
                          ("A/B/ok.mp3", self.MP3)])
        self.assertEqual(self.paths(plan), ["A/B/ok.mp3"])
        self.assertEqual(plan.dangerous, 3)

    def test_other_file_types_are_ignored(self):
        plan = self.plan([("A/B/run.exe", b"MZ"), ("A/B/page.html", b"<x>"), ("A/B/ok.mp3", self.MP3),
                          ("__MACOSX/A/B/._ok.mp3", b"x"), ("A/B/.hidden.mp3", self.MP3)])
        self.assertEqual(self.paths(plan), ["A/B/ok.mp3"])
        self.assertEqual(plan.ignored, 4)

    def test_archive_without_audio_is_refused(self):
        with self.assertRaises(ValueError):
            self.plan([("A/B/cover.jpg", b"\xff\xd8\xff")])

    def test_unzipped_limit(self):
        with self.assertRaises(ValueError):
            self.plan([("A/B/ok.mp3", self.MP3)], limit=5)


class FolderMatcherTest(unittest.TestCase):
    def test_reuses_existing_folder_with_other_case(self):
        with tempfile.TemporaryDirectory() as root:
            os.makedirs(os.path.join(root, "ABBA", "Arrival"))
            matcher = FolderMatcher(root)
            self.assertEqual(matcher.resolve(["Abba", "arrival", "CD1"]), ["ABBA", "Arrival", "CD1"])
            self.assertEqual(matcher.resolve(["Nouveau", "Album"]), ["Nouveau", "Album"])


class PolicyTest(unittest.TestCase):
    def test_ttls(self):
        policy = CachePolicy()
        self.assertEqual(policy.ttl_for("stream", {}), 0)
        self.assertEqual(policy.ttl_for("getAlbumList2", {"type": "random"}), 0)
        self.assertEqual(policy.ttl_for("getAlbumList2", {"type": "recent"}), 30)
        self.assertGreater(policy.ttl_for("getArtists", {}), 86400)

    def test_star_invalidates_starred(self):
        rule = CachePolicy().stale_rule("star", {})
        self.assertTrue(rule({"ep": "getStarred2"}))
        self.assertFalse(rule({"ep": "getArtists"}))

    def test_read_only_calls_invalidate_nothing(self):
        self.assertIsNone(CachePolicy().stale_rule("getArtists", {}))


class JsonCacheTest(unittest.TestCase):
    def test_roundtrip_expiry_and_invalidate(self):
        with tempfile.TemporaryDirectory() as directory:
            cache = JsonCache(directory)
            cache.load()
            cache.put("k1", "getArtists", [], 100, "application/json", b"{}")
            cache.put("k2", "getAlbum", [("id", "1")], -1, "application/json", b"{}")
            self.assertEqual(cache.get("k1").body, b"{}")
            self.assertIsNone(cache.get("k2"))
            self.assertIsNotNone(cache.get("k2", allow_stale=True))
            cache.invalidate(lambda meta: meta["ep"] == "getArtists")
            self.assertIsNone(cache.get("k1"))

    def test_index_is_rebuilt_from_disk(self):
        with tempfile.TemporaryDirectory() as directory:
            first = JsonCache(directory)
            first.load()
            first.put("k", "getArtists", [], 100, "application/json", b"[1]")
            second = JsonCache(directory)
            second.load()
            self.assertEqual(second.get("k").body, b"[1]")


class AuthTest(unittest.TestCase):
    def test_token_is_salted_md5(self):
        salt, token = make_token("secret")
        self.assertEqual(len(salt), 16)
        self.assertEqual(len(token), 32)
        self.assertNotEqual(make_token("secret")[1], token)

    def test_session_expiry(self):
        self.assertFalse(Session("u", "s", "t", time.time() - 1).valid())
        self.assertTrue(Session("u", "s", "t", time.time() + 60).valid())

    def test_session_store_persists_without_password(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "sessions.json")
            store = SessionStore(path, 30)
            sid = store.create("alice", "salt", "token")
            self.assertEqual(oct(os.stat(path).st_mode & 0o777), "0o600")
            with open(path, encoding="utf-8") as f:
                self.assertNotIn("secret", f.read())
            reloaded = SessionStore(path, 30)
            reloaded.load()
            self.assertEqual(reloaded.get(sid).user, "alice")
            reloaded.delete(sid)
            self.assertIsNone(reloaded.get(sid))

    def test_throttle_blocks_after_eight_failures(self):
        throttle = LoginThrottle()
        for _ in range(8):
            self.assertFalse(throttle.blocked("1.2.3.4"))
            throttle.record_failure("1.2.3.4")
        self.assertTrue(throttle.blocked("1.2.3.4"))
        self.assertFalse(throttle.blocked("5.6.7.8"))
        throttle.reset("1.2.3.4")
        self.assertFalse(throttle.blocked("1.2.3.4"))

    def test_user_settings_accept_only_valid_values(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "pi-media.db")
            settings = UserSettings(Database(path), USER_DEFAULTS, USER_CHOICES)
            settings.update("a/b", {"browse_mode": "tags", "quality": "hack"})
            self.assertEqual(settings.get("a/b"), {"browse_mode": "tags", "quality": "raw"})
            self.assertEqual(UserSettings(Database(path), USER_DEFAULTS, USER_CHOICES).get("a/b")["browse_mode"], "tags")


class TransportTest(unittest.TestCase):
    def request(self, target="/", headers=None, peer="127.0.0.1"):
        return Request("GET", target, headers or {}, peer, io.BytesIO())

    def test_cookie_and_params(self):
        request = self.request("/x?a=1&b=2", {"Cookie": "foo=1; pmsid=abc; z=3"})
        self.assertEqual(request.session_id, "abc")
        self.assertEqual(request.param("b"), "2")
        self.assertEqual(request.param("missing", "d"), "d")

    def test_forwarded_ip_only_trusted_from_loopback(self):
        headers = {"X-Forwarded-For": "9.9.9.9, 127.0.0.1"}
        self.assertEqual(self.request(headers=headers).client_ip, "9.9.9.9")
        self.assertEqual(self.request(headers=headers, peer="8.8.8.8").client_ip, "8.8.8.8")

    def test_same_origin(self):
        self.assertTrue(self.request(headers={"Host": "a.fr"}).same_origin())
        self.assertTrue(self.request(headers={"Host": "a.fr", "Origin": "https://a.fr"}).same_origin())
        self.assertFalse(self.request(headers={"Host": "a.fr", "Origin": "https://evil.com"}).same_origin())

    def test_router_exact_and_prefix(self):
        router = Router()
        router.add("GET", "/me", "me")
        router.add_prefix("GET", "/rest/", "rest")
        self.assertEqual(router.find("GET", "/me"), "me")
        self.assertEqual(router.find("GET", "/rest/ping.view"), "rest")
        self.assertIsNone(router.find("POST", "/me"))
        self.assertIsNone(router.find("GET", "/other"))

    def test_etag_matching(self):
        self.assertTrue(etag_matches('"a", "b"', '"b"'))
        self.assertTrue(etag_matches("*", '"x"'))
        self.assertFalse(etag_matches("", '"x"'))


if __name__ == "__main__":
    unittest.main()
