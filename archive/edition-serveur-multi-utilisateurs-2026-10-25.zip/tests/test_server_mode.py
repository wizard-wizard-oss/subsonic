"""Tests d'intégration, mode serveur : connexion, cookies, CSRF, cache par utilisateur, envois ZIP."""
import io
import os
import time
import zipfile

from tests.support import AppTestCase

MP3 = b"ID3\x04\x00" + b"0" * 64


def make_zip(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in entries:
            archive.writestr(name, data)
    return buffer.getvalue()


class ServerModeTest(AppTestCase):
    SERVER_MODE = True

    def rest(self, client, endpoint, query="", **kwargs):
        return client.get("/rest/%s.view?%s" % (endpoint, query), **kwargs)

    def logged_in(self, user="alice", password="secret"):
        client = self.new_client()
        self.assertEqual(self.login(client, user, password).status, 200)
        return client

    # --- accès ---
    def test_api_requires_login(self):
        self.assertEqual(self.rest(self.client, "getGenres").status, 401)
        self.assertEqual(self.client.get("/settings").status, 401)
        self.assertEqual(self.client.get("/me").status, 401)

    def test_login_page_and_assets_are_public(self):
        self.assertEqual(self.client.get("/", csrf=False).status, 200)
        self.assertEqual(self.client.get("/static/js/core.js", csrf=False).status, 200)

    def test_wrong_password_is_refused(self):
        self.assertEqual(self.login(self.client, "alice", "bad").status, 401)
        self.assertEqual(self.login(self.client, "nobody", "x").status, 401)
        self.assertEqual(self.login(self.client, "", "").status, 401)

    def test_login_sets_secure_cookie_and_identity(self):
        response = self.login(self.client)
        cookie = response.headers["set-cookie"]
        for flag in ("HttpOnly", "SameSite=Lax", "Path=/"):
            self.assertIn(flag, cookie)
        me = self.client.get("/me").json()
        self.assertEqual((me["user"], me["admin"], me["upload"]), ("alice", True, True))

    def test_secure_flag_behind_https_proxy(self):
        response = self.client.post_json("/login", {"user": "alice", "pass": "secret"},
                                         headers={"X-Forwarded-Proto": "https"})
        self.assertIn("Secure", response.headers["set-cookie"])

    def test_logout_ends_session(self):
        client = self.logged_in()
        self.assertEqual(client.post_json("/logout", {}).status, 200)
        client.cookie = self.client.cookie     # navigateur sans cookie
        self.assertEqual(client.get("/me").status, 401)

    def test_password_is_not_stored(self):
        self.logged_in()
        with open(self.app.paths.sessions_file, encoding="utf-8") as f:
            self.assertNotIn("secret", f.read())

    def test_login_is_throttled(self):
        for _ in range(8):
            self.assertEqual(self.login(self.client, "alice", "bad").status, 401)
        self.assertEqual(self.login(self.client, "alice", "secret").status, 429)

    def test_login_from_another_site_is_refused(self):
        response = self.client.post_json("/login", {"user": "alice", "pass": "secret"},
                                         headers={"Origin": "https://evil.example"})
        self.assertEqual(response.status, 403)

    # --- CSRF et en-têtes ---
    def test_csrf_header_required_except_for_media(self):
        client = self.logged_in()
        self.assertEqual(self.rest(client, "getGenres", csrf=False).status, 403)
        self.assertEqual(self.rest(client, "getGenres").status, 200)
        self.assertEqual(self.rest(client, "getCoverArt", "id=al1", csrf=False).status, 200)
        self.assertEqual(self.rest(client, "stream", "id=s1", csrf=False).status, 200)

    def test_cross_site_requests_are_refused(self):
        client = self.logged_in()
        response = self.rest(client, "getGenres", headers={"Sec-Fetch-Site": "cross-site"})
        self.assertEqual(response.status, 403)

    def test_index_has_strict_content_security_policy(self):
        headers = self.client.get("/", csrf=False).headers
        self.assertIn("script-src 'self'", headers["content-security-policy"])
        self.assertEqual(headers["x-frame-options"], "DENY")
        self.assertEqual(headers["x-content-type-options"], "nosniff")

    def test_pi_only_endpoints_are_disabled(self):
        client = self.logged_in()
        for path in ("/control/send?cmd=x", "/control/volume", "/control/quit", "/control/mode?m=tags"):
            self.assertEqual(client.get(path).status, 404, path)

    # --- données par utilisateur ---
    def test_each_user_has_own_settings(self):
        alice, bob = self.logged_in("alice", "secret"), self.logged_in("bob", "pw2")
        alice.get("/settings?browse_mode=tags")
        self.assertEqual(alice.get("/settings").json()["browse_mode"], "tags")
        self.assertEqual(bob.get("/settings").json()["browse_mode"], "folders")

    def test_cache_is_not_shared_between_users(self):
        alice, bob = self.logged_in("alice", "secret"), self.logged_in("bob", "pw2")
        self.assertEqual(self.rest(alice, "getStarred2").headers["x-cache"], "MISS")
        self.assertEqual(self.rest(alice, "getStarred2").headers["x-cache"], "HIT")
        self.assertEqual(self.rest(bob, "getStarred2").headers["x-cache"], "MISS")

    def test_covers_are_shared_between_users(self):
        alice, bob = self.logged_in("alice", "secret"), self.logged_in("bob", "pw2")
        self.rest(alice, "getCoverArt", "id=al1", csrf=False)
        self.assertEqual(self.rest(bob, "getCoverArt", "id=al1", csrf=False).headers["x-cache"], "HIT")

    def test_only_admins_clear_everything(self):
        alice, bob = self.logged_in("alice", "secret"), self.logged_in("bob", "pw2")
        self.rest(alice, "getCoverArt", "id=al1", csrf=False)
        bob.get("/cache/clear?all=1")
        self.assertEqual(self.rest(alice, "getCoverArt", "id=al1", csrf=False).headers["x-cache"], "HIT")
        alice.get("/cache/clear?all=1")
        self.assertEqual(self.rest(alice, "getCoverArt", "id=al1", csrf=False).headers["x-cache"], "MISS")

    # --- envois ZIP ---
    def upload(self, client, data, query="name=test.zip", headers=None):
        return client.request("POST", "/upload?" + query, body=data, headers=headers)

    def wait_for_job(self, client):
        for _ in range(100):
            jobs = client.get("/upload/list").json()
            if jobs and jobs[0]["state"] in ("termine", "erreur"):
                return jobs[0]
            time.sleep(0.1)
        self.fail("envoi trop long")

    def music_files(self):
        return sorted(os.path.relpath(os.path.join(root, f), self.music_dir)
                      for root, _, files in os.walk(self.music_dir) for f in files)

    def test_upload_requires_login(self):
        self.assertEqual(self.upload(self.client, make_zip([("A/B/1.mp3", MP3)])).status, 401)

    def test_only_allowed_users_can_upload(self):
        bob = self.logged_in("bob", "pw2")
        response = self.upload(bob, make_zip([("A/B/1.mp3", MP3)]))
        self.assertEqual(response.status, 403)
        self.assertEqual(self.music_files(), [])

    def test_valid_zip_is_unpacked_in_artist_album_folders(self):
        alice = self.logged_in()
        response = self.upload(alice, make_zip([("ABBA/Arrival/01.mp3", MP3), ("ABBA/Arrival/cover.jpg", b"\xff\xd8\xff0")]))
        self.assertEqual(response.status, 202)
        job = self.wait_for_job(alice)
        self.assertEqual((job["state"], job["added"]), ("termine", 2))
        self.assertEqual(self.music_files(), ["ABBA/Arrival/01.mp3", "ABBA/Arrival/cover.jpg"])
        self.assertGreaterEqual(self.subsonic.calls["startScan"], 1)

    def test_folder_with_other_case_is_reused(self):
        os.makedirs(os.path.join(self.music_dir, "ABBA", "Arrival"))
        alice = self.logged_in()
        self.upload(alice, make_zip([("abba/arrival/02.mp3", MP3)]))
        self.wait_for_job(alice)
        self.assertEqual(self.music_files(), ["ABBA/Arrival/02.mp3"])

    def test_existing_files_are_never_overwritten(self):
        folder = os.path.join(self.music_dir, "A", "B")
        os.makedirs(folder)
        with open(os.path.join(folder, "1.mp3"), "wb") as f:
            f.write(b"ORIGINAL")
        alice = self.logged_in()
        self.upload(alice, make_zip([("A/B/1.mp3", MP3)]))
        job = self.wait_for_job(alice)
        self.assertEqual(job["existants"], 1)
        with open(os.path.join(folder, "1.mp3"), "rb") as f:
            self.assertEqual(f.read(), b"ORIGINAL")

    def test_disguised_file_is_refused(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("A/B/ok.mp3", MP3), ("A/B/fake.mp3", b"MZ\x90\x00 programme"),
                                     ("A/B/shell.php", b"<?php ?>")]))
        job = self.wait_for_job(alice)
        self.assertEqual(self.music_files(), ["A/B/ok.mp3"])
        self.assertEqual((job["dangereux"], job["ignores"]), (1, 1))

    def test_zip_slip_stays_inside_music_folder(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("../../evil.mp3", MP3), ("A/B/ok.mp3", MP3)]))
        job = self.wait_for_job(alice)
        self.assertEqual(self.music_files(), ["A/B/ok.mp3"])
        self.assertEqual(job["dangereux"], 1)
        self.assertFalse(os.path.exists(os.path.join(os.path.dirname(self.music_dir), "evil.mp3")))

    def test_loose_files_go_to_unsorted_folder(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("01.mp3", MP3)]), query="name=Vacances.zip")
        job = self.wait_for_job(alice)
        self.assertTrue(job["a_classer"])
        self.assertEqual(self.music_files(), ["À classer/Vacances/01.mp3"])

    def test_upload_with_artist_name(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("Post/01.mp3", MP3)]), query="name=x.zip&artist=Bj%C3%B6rk")
        self.wait_for_job(alice)
        self.assertEqual(self.music_files(), ["Björk/Post/01.mp3"])

    def test_not_a_zip_is_refused(self):
        alice = self.logged_in()
        response = self.upload(alice, b"MZ" + b"0" * 100)
        self.assertEqual(response.status, 400)
        self.assertIn("ZIP", response.json()["error"])

    def test_zip_without_audio_fails_cleanly(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("readme.txt", b"hello")]))
        job = self.wait_for_job(alice)
        self.assertEqual(job["state"], "erreur")
        self.assertEqual(self.music_files(), [])

    def test_temp_archive_is_deleted(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("A/B/1.mp3", MP3)]))
        self.wait_for_job(alice)
        time.sleep(0.2)
        self.assertEqual(os.listdir(self.app.paths.tmp_dir), [])

    def test_upload_from_another_site_is_refused(self):
        alice = self.logged_in()
        response = self.upload(alice, make_zip([("A/B/1.mp3", MP3)]), headers={"Origin": "https://evil.example"})
        self.assertEqual(response.status, 403)

    def test_missing_content_length_is_refused(self):
        alice = self.logged_in()
        self.assertEqual(self.upload(alice, b"").status, 411)

    def test_users_only_see_their_own_uploads(self):
        alice = self.logged_in()
        self.upload(alice, make_zip([("A/B/1.mp3", MP3)]))
        self.wait_for_job(alice)
        bob = self.logged_in("bob", "pw2")
        self.assertEqual(bob.get("/upload/list").json(), [])


class UploadLimitsTest(AppTestCase):
    SERVER_MODE = True
    EXTRA_CONFIG = {"upload_max_mb": 0}

    def test_size_limit(self):
        alice = self.new_client()
        self.login(alice)
        response = alice.request("POST", "/upload?name=x.zip", body=make_zip([("A/B/1.mp3", MP3)]))
        self.assertEqual(response.status, 413)


class ZipBombTest(AppTestCase):
    SERVER_MODE = True
    EXTRA_CONFIG = {"upload_max_unzipped_mb": 1}

    def test_unzipped_limit_refuses_bomb(self):
        alice = self.new_client()
        self.login(alice)
        bomb = make_zip([("A/B/big.mp3", MP3 + b"\x00" * (3 * 1048576))])
        self.assertLess(len(bomb), 100000)           # très compressé
        alice.request("POST", "/upload?name=bomb.zip", body=bomb)
        for _ in range(100):
            jobs = alice.get("/upload/list").json()
            if jobs and jobs[0]["state"] in ("termine", "erreur"):
                break
            time.sleep(0.1)
        self.assertEqual(jobs[0]["state"], "erreur")
        self.assertFalse(os.listdir(self.music_dir))
