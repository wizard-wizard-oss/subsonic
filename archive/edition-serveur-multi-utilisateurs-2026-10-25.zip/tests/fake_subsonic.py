"""Faux serveur Subsonic pour les tests : vérifie le jeton, sert une petite bibliothèque, compte les appels."""
import hashlib
import json
import threading
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlsplit

USERS = {"alice": "secret", "bob": "pw2"}
AUDIO = bytes(range(256)) * 40                   # 10 240 octets
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 32

SONGS = {
    "s1": {"id": "s1", "title": "Dancing Queen", "artist": "ABBA", "track": 2, "discNumber": 1, "duration": 230},
    "s2": {"id": "s2", "title": "Knowing Me", "artist": "ABBA", "track": 1, "discNumber": 1, "duration": 240},
    "s3": {"id": "s3", "title": "Waterloo", "artist": "Abba", "track": 1, "duration": 170},
    "s4": {"id": "s4", "title": "Army of Me", "artist": "Björk", "track": 1, "duration": 235},
}
DIRECTORIES = {
    "ar1": {"id": "ar1", "name": "ABBA", "child": [
        {"id": "al1", "isDir": True, "title": "Arrival", "parent": "ar1"}]},
    "ar2": {"id": "ar2", "name": "Abba", "child": [
        {"id": "al2", "isDir": True, "title": "Waterloo", "parent": "ar2"},
        {"id": "al1b", "isDir": True, "title": "arrival", "parent": "ar2"}]},
    "ar3": {"id": "ar3", "name": "Björk", "child": [
        {"id": "al3", "isDir": True, "title": "Post", "parent": "ar3"}]},
    "al1": {"id": "al1", "name": "Arrival", "parent": "ar1", "child": [SONGS["s1"], SONGS["s2"]]},
    "al2": {"id": "al2", "name": "Waterloo", "parent": "ar2", "child": [SONGS["s3"]]},
    "al3": {"id": "al3", "name": "Post", "parent": "ar3", "child": [SONGS["s4"]]},
}
INDEXES = [{"name": "A", "artist": [{"id": "ar1", "name": "ABBA"}, {"id": "ar2", "name": "Abba"}]},
           {"name": "B", "artist": [{"id": "ar3", "name": "Björk"}]}]


class FakeSubsonic:
    """À utiliser dans un test : start() puis .url ; calls compte les appels par méthode."""

    def __init__(self):
        self.calls = Counter()
        self.users = dict(USERS)
        self.newest = ["al1", "al2"]
        owner = self
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), self._make_handler(owner))
        self._server.daemon_threads = True

    @property
    def url(self):
        return "http://127.0.0.1:%d" % self._server.server_address[1]

    def start(self):
        threading.Thread(target=self._server.serve_forever, daemon=True).start()
        return self

    def stop(self):
        self._server.shutdown()
        self._server.server_close()

    @staticmethod
    def _make_handler(owner):
        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args):
                pass

            def do_GET(self):
                parts = urlsplit(self.path)
                name = parts.path.rsplit("/", 1)[-1].replace(".view", "")
                params = dict(parse_qsl(parts.query))
                owner.calls[name] += 1
                if not owner.token_valid(params):
                    return self.reply_json({"status": "failed", "error": {"code": 40, "message": "Wrong credentials"}})
                getattr(owner, "api_" + name, owner.api_unknown)(self, params)

            def reply_json(self, content):
                content.setdefault("version", "1.16.1")
                self.reply(200, json.dumps({"subsonic-response": dict(content, status=content.get("status", "ok"))}).encode(),
                           "application/json")

            def reply(self, status, body, ctype, extra=None):
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                for key, value in (extra or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)
        return Handler

    # --- authentification ---
    def token_valid(self, params):
        password = self.users.get(params.get("u", ""))
        if password is None:
            return False
        return params.get("t") == hashlib.md5((password + params.get("s", "")).encode()).hexdigest()

    # --- méthodes de l'API ---
    def api_unknown(self, h, p):
        h.reply_json({"status": "failed", "error": {"code": 70, "message": "inconnu"}})

    def api_ping(self, h, p):
        h.reply_json({})

    def api_getIndexes(self, h, p):
        h.reply_json({"indexes": {"index": INDEXES}})

    def api_getMusicDirectory(self, h, p):
        directory = DIRECTORIES.get(p.get("id"))
        if directory is None:
            return h.reply_json({"status": "failed", "error": {"code": 70, "message": "introuvable"}})
        h.reply_json({"directory": directory})

    def api_getAlbumList(self, h, p):
        h.reply_json({"albumList": {"album": [DIRECTORIES[i] and
                                              {"id": i, "title": DIRECTORIES[i]["name"], "parent": DIRECTORIES[i]["parent"]}
                                              for i in self.newest]}})

    def api_getAlbumList2(self, h, p):
        h.reply_json({"albumList2": {"album": [{"id": i, "name": DIRECTORIES[i]["name"]} for i in self.newest]}})

    def api_getStarred(self, h, p):
        h.reply_json({"starred": {"song": [SONGS["s1"]]}})

    def api_search2(self, h, p):
        query = (p.get("query") or "").lower()
        songs = [s for s in SONGS.values() if query and (query in s["title"].lower() or query in s["artist"].lower())]
        h.reply_json({"searchResult2": {"artist": [{"id": "ar1", "name": "ABBA"}, {"id": "ar2", "name": "Abba"}], "song": songs}})

    def api_getArtistInfo(self, h, p):
        h.reply_json({"artistInfo": {"biography": "ABBA est un groupe suédois de pop formé à Stockholm en 1972."}})

    def api_getLyrics(self, h, p):
        h.reply_json({"lyrics": {"value": ""}})

    def api_startScan(self, h, p):
        h.reply_json({"scanStatus": {"scanning": True}})

    def api_star(self, h, p):
        h.reply_json({})

    def api_getPlaylists(self, h, p):
        h.reply_json({"playlists": {}})

    def api_getGenres(self, h, p):
        h.reply_json({"genres": {}})

    def api_getCoverArt(self, h, p):
        h.reply(200, PNG, "image/png")

    def api_stream(self, h, p):
        wanted = h.headers.get("Range")
        if not wanted:
            return h.reply(200, AUDIO, "audio/mpeg", {"Accept-Ranges": "bytes"})
        start, _, end = wanted.replace("bytes=", "").partition("-")
        first, last = int(start), int(end) if end else len(AUDIO) - 1
        h.reply(206, AUDIO[first:last + 1], "audio/mpeg",
                {"Content-Range": "bytes %d-%d/%d" % (first, last, len(AUDIO)), "Accept-Ranges": "bytes"})
