"""Lecture haute fidélité : mpv piloté par son protocole JSON (ici un faux mpv qui parle le même protocole)."""
import json
import os
import sys
import tempfile
import time
import unittest

from pimedia.server.playback import CLIENT_NAME, HifiPlayer, mpv_command
from tests.support import PROJECT, AppTestCase

FAKE_MPV = [sys.executable, os.path.join(PROJECT, "tests", "fake_mpv.py")]


class FakeConfig:
    def __init__(self):
        self.values = {}

    def get(self, key, default=None):
        return self.values.get(key, default)

    def update(self, **changes):
        self.values.update(changes)


def wait_for(condition, timeout=3):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if condition():
            return True
        time.sleep(0.02)
    return False


class HifiPlayerTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="pm-mpv-")
        self.socket = os.path.join(self.dir, "mpv.sock")
        self.player = HifiPlayer(FakeConfig(), self.socket, lambda: "http://127.0.0.1:8099",
                                 FAKE_MPV + ["--input-ipc-server=" + self.socket])
        self.addCleanup(self.player.mpv.stop)

    def commands(self):
        with open(self.socket + ".log") as log:
            return [json.loads(line) for line in log]

    def test_command_line_keeps_the_original_sample_rate(self):
        command = mpv_command("/tmp/s")
        self.assertIn("--gapless-audio=yes", command)
        self.assertIn("--audio-client-name=" + CLIENT_NAME, command)
        self.assertFalse(any("samplerate" in c for c in command))    # aucune fréquence imposée : celle du fichier

    def test_load_plays_through_the_local_relay(self):
        self.player.load("/rest/stream.view?id=71048&format=raw")
        self.assertIn(["loadfile", "http://127.0.0.1:8099/rest/stream.view?id=71048&format=raw", "replace"], self.commands())
        self.assertTrue(wait_for(lambda: self.player.state()["duration"] == 261.0))
        state = self.player.state()
        self.assertEqual((state["url"], state["paused"], state["idle"]), ("/rest/stream.view?id=71048&format=raw", False, False))

    def test_refuses_other_addresses(self):
        for bad in ("/rest/deleteUser.view?u=x", "file:///etc/passwd", "http://127.0.0.1:22/", "http://localhost/x", ""):
            with self.assertRaises(ValueError, msg=bad):
                self.player.resolve(bad)
        self.assertEqual(self.player.resolve("https://radio.example/stream"), "https://radio.example/stream")

    def test_gapless_next_track(self):
        first, second = "/rest/stream.view?id=1&format=raw", "/rest/stream.view?id=2&format=raw"
        self.player.load(first)
        self.player.preload(second)
        self.assertEqual(self.commands()[-1], ["loadfile", "http://127.0.0.1:8099/rest/stream.view?id=2&format=raw", "append"])
        self.player.mpv.call("test-finish")
        self.assertTrue(wait_for(lambda: self.player.state()["ended"] == 1))
        self.assertEqual((self.player.state()["url"], self.player.state()["queued"]), (second, ""))
        loads_before = len([c for c in self.commands() if c[0] == "loadfile"])
        self.player.load(second)                        # la page demande le titre suivant : déjà en cours, rien à recharger
        self.assertEqual(len([c for c in self.commands() if c[0] == "loadfile"]), loads_before)

    def test_pause_seek_volume_and_errors(self):
        self.player.load("/rest/stream.view?id=1")
        self.player.pause(True)
        self.assertTrue(wait_for(lambda: self.player.state()["paused"]))
        self.player.seek(42)
        self.assertTrue(wait_for(lambda: self.player.state()["pos"] == 42.0))
        self.player.volume(150)
        self.assertIn(["set_property", "volume", 100], self.commands())
        self.player.mpv.call("test-fail")
        self.assertTrue(wait_for(lambda: self.player.state()["errors"] == 1))

    def test_restarts_mpv_if_it_stopped(self):
        self.player.load("/rest/stream.view?id=1")
        self.player.mpv.process.kill()
        self.player.mpv.process.wait()
        self.player.load("/rest/stream.view?id=2")
        self.assertEqual(self.player.state()["url"], "/rest/stream.view?id=2")


class PlayerApiTest(AppTestCase):
    def setUp(self):
        super().setUp()
        sock = os.path.join(tempfile.mkdtemp(prefix="pm-mpv-"), "mpv.sock")
        self.app.hifi.mpv.socket_path = sock
        self.app.hifi.mpv.command = FAKE_MPV + ["--input-ipc-server=" + sock]
        self.addCleanup(self.app.hifi.mpv.stop)

    def cmd(self, body, **kwargs):
        return self.client.post_json("/player/cmd", body, **kwargs)

    def test_enable_load_and_state(self):
        self.assertFalse(self.client.get("/player/state", csrf=False).json()["enabled"])
        self.assertTrue(self.cmd({"action": "enable", "value": True}).json()["enabled"])
        self.assertEqual(self.cmd({"action": "load", "url": "/rest/stream.view?id=9&format=raw"}).status, 200)
        self.assertEqual(self.client.get("/player/state", csrf=False).json()["url"], "/rest/stream.view?id=9&format=raw")

    def test_refusals(self):
        self.assertEqual(self.cmd({"action": "load", "url": "/rest/stream.view?id=1"}, csrf=False).status, 403)
        self.assertEqual(self.cmd({"action": "load", "url": "file:///etc/passwd"}).status, 400)
        self.assertEqual(self.cmd({"action": "rm -rf"}).status, 400)


class PlayerServerModeTest(AppTestCase):
    SERVER_MODE = True

    def test_not_available_in_server_mode(self):
        self.login(self.client)
        self.assertEqual(self.client.get("/player/state").status, 404)


if __name__ == "__main__":
    unittest.main()
